import nodeHTTP from "node:http";
import { Readable, PassThrough } from "node:stream";
import { pipeline } from "node:stream/promises";
import nodeHTTPS from "node:https";
import nodeHTTP2 from "node:http2";
function lazyInherit$2(target, source, sourceKey) {
  for (const key of [...Object.getOwnPropertyNames(source), ...Object.getOwnPropertySymbols(source)]) {
    if (key === "constructor") continue;
    const targetDesc = Object.getOwnPropertyDescriptor(target, key);
    const desc = Object.getOwnPropertyDescriptor(source, key);
    let modified = false;
    if (desc.get) {
      modified = true;
      desc.get = targetDesc?.get || function() {
        return this[sourceKey][key];
      };
    }
    if (desc.set) {
      modified = true;
      desc.set = targetDesc?.set || function(value) {
        this[sourceKey][key] = value;
      };
    }
    if (!targetDesc?.value && typeof desc.value === "function") {
      modified = true;
      desc.value = function(...args) {
        return this[sourceKey][key](...args);
      };
    }
    if (modified) Object.defineProperty(target, key, desc);
  }
}
const _needsNormRE$2 = /(?:(?:^|\/)(?:\.|\.\.|%2e|%2e\.|\.%2e|%2e%2e)(?:\/|$))|[\\^#"<>{}`\x00-\x20\x7f-\uffff]/i;
const _searchNeedsNormRE$2 = /[#"'<>\x00-\x20\x7f-\uffff]/;
const FastURL$2 = /* @__PURE__ */ (() => {
  const NativeURL = globalThis.URL;
  const NativeSearchParams = globalThis.URLSearchParams;
  const FastURLSearchParams = class URLSearchParams {
    #owner;
    #params;
    constructor(owner) {
      this.#owner = owner;
    }
    static [Symbol.hasInstance](val) {
      return val instanceof NativeSearchParams;
    }
    _adopt(params) {
      this.#params = params;
    }
    get _params() {
      if (!this.#params) {
        const search = this.#owner.search;
        this.#params ??= new NativeSearchParams(search);
      }
      return this.#params;
    }
    #mutable() {
      this.#owner._url;
      return this.#params;
    }
    append(name, value) {
      this.#mutable().append(name, value);
    }
    set(name, value) {
      this.#mutable().set(name, value);
    }
    delete(name, value) {
      this.#mutable().delete(name, value);
    }
    sort() {
      this.#mutable().sort();
    }
  };
  lazyInherit$2(FastURLSearchParams.prototype, NativeSearchParams.prototype, "_params");
  Object.setPrototypeOf(FastURLSearchParams.prototype, NativeSearchParams.prototype);
  Object.setPrototypeOf(FastURLSearchParams, NativeSearchParams);
  const FastURL2 = class URL {
    #url;
    #href;
    #protocol;
    #host;
    #pathname;
    #search;
    #searchParams;
    #pos;
    constructor(url) {
      if (typeof url === "string") {
        const isOriginForm = url[0] === "/";
        if (isOriginForm && !_searchNeedsNormRE$2.test(url)) this.#href = `http://localhost${url}`;
        else this.#url = new NativeURL(isOriginForm ? `http://localhost${url}` : url);
      } else if (_needsNormRE$2.test(url.pathname) || url.search && _searchNeedsNormRE$2.test(url.search)) this.#url = new NativeURL(`${url.protocol || "http:"}//${url.host || "localhost"}${url.pathname}${url.search || ""}`);
      else {
        this.#protocol = url.protocol;
        this.#host = url.host;
        this.#pathname = url.pathname;
        this.#search = url.search;
      }
    }
    static [Symbol.hasInstance](val) {
      return val instanceof NativeURL;
    }
    get _url() {
      if (this.#url) return this.#url;
      this.#url = new NativeURL(this.href);
      this.#href = void 0;
      this.#protocol = void 0;
      this.#host = void 0;
      this.#pathname = void 0;
      this.#search = void 0;
      this.#pos = void 0;
      this.#searchParams?._adopt(this.#url.searchParams);
      return this.#url;
    }
    get href() {
      if (this.#url) return this.#url.href;
      if (!this.#href) this.#href = `${this.#protocol || "http:"}//${this.#host || "localhost"}${this.#pathname || "/"}${this.#search || ""}`;
      return this.#href;
    }
    #getPos() {
      if (!this.#pos) {
        const url = this.href;
        const protoIndex = url.indexOf("://");
        const pathnameIndex = protoIndex === -1 ? -1 : url.indexOf("/", protoIndex + 4);
        const qIndex = pathnameIndex === -1 ? -1 : url.indexOf("?", pathnameIndex);
        this.#pos = [
          protoIndex,
          pathnameIndex,
          qIndex
        ];
      }
      return this.#pos;
    }
    get pathname() {
      if (this.#url) return this.#url.pathname;
      if (this.#pathname === void 0) {
        const [, pathnameIndex, queryIndex] = this.#getPos();
        if (pathnameIndex === -1) return this._url.pathname;
        this.#pathname = this.href.slice(pathnameIndex, queryIndex === -1 ? void 0 : queryIndex);
      }
      return this.#pathname;
    }
    get search() {
      if (this.#url) return this.#url.search;
      if (this.#search === void 0) {
        const [, pathnameIndex, queryIndex] = this.#getPos();
        if (pathnameIndex === -1) return this._url.search;
        const url = this.href;
        this.#search = queryIndex === -1 || queryIndex === url.length - 1 ? "" : url.slice(queryIndex);
      }
      return this.#search;
    }
    get searchParams() {
      if (this.#searchParams) return this.#searchParams;
      if (this.#url) return this.#url.searchParams;
      return this.#searchParams = new FastURLSearchParams(this);
    }
    get protocol() {
      if (this.#url) return this.#url.protocol;
      if (this.#protocol === void 0) {
        const [protocolIndex] = this.#getPos();
        if (protocolIndex === -1) return this._url.protocol;
        const url = this.href;
        this.#protocol = url.slice(0, protocolIndex + 1);
      }
      return this.#protocol;
    }
    get hash() {
      if (this.#url) return this.#url.hash;
      return "";
    }
    toString() {
      return this.href;
    }
    toJSON() {
      return this.href;
    }
  };
  lazyInherit$2(FastURL2.prototype, NativeURL.prototype, "_url");
  Object.setPrototypeOf(FastURL2.prototype, NativeURL.prototype);
  Object.setPrototypeOf(FastURL2, NativeURL);
  return FastURL2;
})();
function resolvePortAndHost(opts) {
  const _port = opts.port ?? globalThis.process?.env.PORT ?? 3e3;
  const port = typeof _port === "number" ? _port : Number.parseInt(_port, 10);
  if (Number.isNaN(port) || port < 0 || port > 65535) throw new RangeError(`Port must be a number between 0 and 65535 (got "${_port}").`);
  return {
    port,
    hostname: opts.hostname ?? globalThis.process?.env.HOST
  };
}
function fmtURL(host, port, secure) {
  if (!host || !port) return;
  if (host.includes(":")) host = `[${host}]`;
  return `http${secure ? "s" : ""}://${host}:${port}/`;
}
function printListening(opts, url) {
  if (!url || (opts.silent ?? globalThis.process?.env?.TEST)) return;
  let additionalInfo = "";
  try {
    const _url = new URL(url);
    if (_url.hostname === "[::]" || _url.hostname === "0.0.0.0") {
      _url.hostname = "localhost";
      url = _url.href;
      additionalInfo = " (all interfaces)";
    }
  } catch {
  }
  let listeningOn = `➜ Listening on:`;
  if (globalThis.process.stdout?.isTTY) {
    listeningOn = `\x1B[32m${listeningOn}\x1B[0m`;
    url = `\x1B[36m${url}\x1B[0m`;
    additionalInfo = `\x1B[2m${additionalInfo}\x1B[0m`;
  }
  console.log(`${listeningOn} ${url}${additionalInfo}`);
}
function resolveTLSOptions(opts) {
  if (!opts.tls || opts.protocol === "http") return;
  const cert = resolveCertOrKey(opts.tls.cert);
  const key = resolveCertOrKey(opts.tls.key);
  if (!cert && !key) {
    if (opts.protocol === "https") throw new TypeError("TLS `cert` and `key` must be provided for `https` protocol.");
    return;
  }
  if (!cert || !key) throw new TypeError("TLS `cert` and `key` must be provided together.");
  return {
    cert,
    key,
    passphrase: opts.tls.passphrase
  };
}
function resolveCertOrKey(value) {
  if (!value) return;
  if (typeof value !== "string") throw new TypeError("TLS certificate and key must be strings in PEM format or file paths.");
  if (value.startsWith("-----BEGIN ")) return value;
  const { readFileSync } = process.getBuiltinModule("node:fs");
  return readFileSync(value, "utf8");
}
function createWaitUntil() {
  const promises = /* @__PURE__ */ new Set();
  return {
    waitUntil: (promise) => {
      if (typeof promise?.then !== "function") return;
      const chained = Promise.resolve(promise).catch(console.error).finally(() => {
        promises.delete(chained);
      });
      promises.add(chained);
    },
    wait: () => {
      return Promise.all(promises);
    },
    get _size() {
      return promises.size;
    }
  };
}
function limitBodyStream(stream, maxRequestBodySize, options) {
  const createError = createBodyTooLargeError;
  const reader = stream.getReader();
  let size = 0;
  return new ReadableStream({
    async pull(controller) {
      const { done, value } = await reader.read();
      if (done) {
        controller.close();
        return;
      }
      size += value.byteLength;
      if (size > maxRequestBodySize) {
        const error = createError(maxRequestBodySize);
        reader.cancel(error).catch(() => {
        });
        controller.error(error);
        return;
      }
      controller.enqueue(value);
    },
    cancel(reason) {
      return reader.cancel(reason);
    }
  });
}
var BodyTooLargeError = class extends Error {
  code = "ERR_BODY_TOO_LARGE";
  statusCode = 413;
  status = 413;
  statusText = "Content Too Large";
  get name() {
    return "HTTPError";
  }
  toJSON() {
    return {
      status: this.status,
      statusText: this.statusText,
      message: this.message
    };
  }
};
function createBodyTooLargeError(maxRequestBodySize) {
  return new BodyTooLargeError(`Request body exceeds the maximum allowed size of ${maxRequestBodySize} bytes.`);
}
const noColor = /* @__PURE__ */ (() => {
  const proc = globalThis.process;
  const env = proc?.env ?? {};
  if (env.FORCE_COLOR) return false;
  if (env.NO_COLOR || env.TERM === "dumb") return true;
  return !proc?.stdout?.isTTY;
})();
const _c = (c, r = 39) => (t) => noColor ? t : `\x1B[${c}m${t}\x1B[${r}m`;
const bold = /* @__PURE__ */ _c(1, 22);
const red = /* @__PURE__ */ _c(31);
const green = /* @__PURE__ */ _c(32);
const gray = /* @__PURE__ */ _c(90);
function wrapFetch(server) {
  let composed = server.options.fetch;
  const middleware = server.options.middleware;
  if (middleware) for (let i = middleware.length - 1; i >= 0; i--) {
    const mw = middleware[i];
    const next = composed;
    composed = (request) => mw(request, () => next(request));
  }
  return composed;
}
const errorPlugin = (server) => {
  const errorHandler = server.options.error;
  if (!errorHandler) return;
  server.options.middleware.unshift((_req, next) => {
    try {
      const res = next();
      return typeof res?.then === "function" ? res.then(void 0, (error) => errorHandler(error)) : res;
    } catch (error) {
      return errorHandler(error);
    }
  });
};
const gracefulShutdownPlugin = (server) => {
  const config = server.options?.gracefulShutdown;
  if (!globalThis.process?.on || config === false || config === void 0 && (process.env.CI || process.env.TEST)) return;
  const gracefulTimeout = config === true || !config?.gracefulTimeout ? Number.parseInt(process.env.SERVER_SHUTDOWN_TIMEOUT || "") || 5 : config.gracefulTimeout;
  let isClosing = false;
  let isClosed = false;
  const w = server.options.silent ? () => {
  } : process.stderr.write.bind(process.stderr);
  const forceClose = async () => {
    if (isClosed) return;
    w(red("\x1B[2K\rForcibly closing connections...\n"));
    isClosed = true;
    await server.close(true);
  };
  const shutdown = async () => {
    if (isClosing || isClosed) return;
    setTimeout(() => {
      globalThis.process.once("SIGINT", forceClose);
    }, 100);
    isClosing = true;
    const closePromise = server.close();
    for (let remaining = gracefulTimeout; remaining > 0; remaining--) {
      w(gray(`\rStopping server gracefully (${remaining}s)... Press ${bold("Ctrl+C")} again to force close.`));
      if (await Promise.race([closePromise.then(() => true), new Promise((r) => setTimeout(() => r(false), 1e3))])) {
        w("\x1B[2K\r" + green("Server closed successfully.\n"));
        isClosed = true;
        return;
      }
    }
    w("\x1B[2K\rGraceful shutdown timed out.\n");
    await forceClose();
  };
  for (const sig of ["SIGINT", "SIGTERM"]) globalThis.process.on(sig, shutdown);
};
function isTrustedProxy(trustProxy, remoteAddress) {
  if (trustProxy === void 0 || trustProxy === false) return false;
  if (trustProxy === true) return true;
  if (trustProxy === "loopback") return isLoopbackAddress(remoteAddress);
  if (remoteAddress === void 0) return false;
  if (trustProxy.includes(remoteAddress)) return true;
  const mapped = ipv4FromMapped(remoteAddress);
  return mapped !== void 0 && trustProxy.includes(mapped);
}
function ipv4FromMapped(address) {
  return address.startsWith("::ffff:") && address.includes(".") ? address.slice(7) : void 0;
}
function isLoopbackAddress(address) {
  return !!address && (address === "::1" || address.startsWith("127.") || address.startsWith("::ffff:127."));
}
const HOST_RE = /^(\[(?:[A-Fa-f0-9:.]+)\]|(?:[A-Za-z0-9_-]+\.)*[A-Za-z0-9_-]+|(?:\d{1,3}\.){3}\d{1,3})(:\d{1,5})?$/;
function forwardedList(value) {
  if (!value) return [];
  const raw = Array.isArray(value) ? value.join(",") : value;
  const out = [];
  for (const part of raw.split(",")) {
    const entry = part.trim();
    if (entry) out.push(entry);
  }
  return out;
}
function resolveClientIP(trustProxy, peer, forwardedFor) {
  if (!isTrustedProxy(trustProxy, peer)) return peer;
  const list = forwardedList(forwardedFor);
  for (let i = list.length - 1; i >= 0; i--) if (!isTrustedProxy(trustProxy, list[i])) return list[i];
  return list.length > 0 ? list[0] : peer;
}
function trustedHops(trustProxy, peer, forwardedFor) {
  if (!isTrustedProxy(trustProxy, peer)) return 0;
  const list = forwardedList(forwardedFor);
  let hops = 1;
  for (let i = list.length - 1; i >= 0; i--) {
    if (!isTrustedProxy(trustProxy, list[i])) return hops;
    hops++;
  }
  return Number.POSITIVE_INFINITY;
}
function forwardedHopValue(value, hops) {
  if (hops <= 0) return;
  const list = forwardedList(value);
  if (list.length === 0) return;
  return list[Math.max(0, list.length - hops)];
}
function sendNodeResponseDetached(nodeRes, webRes, silent) {
  try {
    return _sendNodeResponse(nodeRes, webRes, true);
  } catch (error) {
    handleSendError(nodeRes, error, silent);
  }
}
function handleSendError(nodeRes, error, silent) {
  if (!silent) console.error("[srvx] Failed to send response:", error);
  failResponse(nodeRes);
}
function sendErrorResponse(nodeRes, error, silent) {
  if (!silent) console.error("[srvx] Unhandled error in fetch handler:", error);
  failResponse(nodeRes);
}
function failResponse(nodeRes) {
  if (nodeRes.writableEnded) return;
  if (nodeRes.headersSent) nodeRes.destroy();
  else {
    nodeRes.statusCode = 500;
    if (nodeRes.req?.httpVersion !== "2.0") nodeRes.statusMessage = "";
    nodeRes.end();
  }
}
function _sendNodeResponse(nodeRes, webRes, detached) {
  if (!webRes) {
    nodeRes.statusCode = 500;
    return endNodeResponse(nodeRes, detached);
  }
  if (webRes._toNodeResponse) {
    const res = webRes._toNodeResponse();
    if (res.body) {
      if (res.body instanceof ReadableStream) {
        writeHead(nodeRes, res.status, res.statusText, res.headers);
        return streamBody(res.body, nodeRes);
      } else if (typeof res.body?.pipe === "function") return pipeBody(res.body, nodeRes, res.status, res.statusText, res.headers);
      writeHead(nodeRes, res.status, res.statusText, res.headers);
      nodeRes.write(res.body);
    } else writeHead(nodeRes, res.status, res.statusText, res.headers);
    return endNodeResponse(nodeRes, detached);
  }
  const rawHeaders = [];
  for (const [key, value] of webRes.headers) rawHeaders.push(key, value);
  writeHead(nodeRes, webRes.status, webRes.statusText, rawHeaders);
  return webRes.body ? streamBody(webRes.body, nodeRes) : endNodeResponse(nodeRes, detached);
}
function writeHead(nodeRes, status, statusText, rawHeaders) {
  if (!nodeRes.headersSent) {
    if (nodeRes.req?.httpVersion === "2.0") nodeRes.writeHead(status, rawHeaders);
    else nodeRes.writeHead(status, safeStatusText(statusText), rawHeaders);
  }
}
const INVALID_REASON_PHRASE_RE = /[^\t\u0020-\u007E\u0080-\u00FF]/g;
function safeStatusText(statusText) {
  return typeof statusText === "string" && statusText ? statusText.replace(INVALID_REASON_PHRASE_RE, "") : statusText;
}
function endNodeResponse(nodeRes, detached) {
  if (detached) {
    nodeRes.end();
    return;
  }
  return new Promise((resolve) => nodeRes.end(resolve));
}
function pipeBody(stream, nodeRes, status, statusText, headers) {
  if (nodeRes.destroyed) {
    stream.destroy?.();
    return;
  }
  if (nodeRes.req?.method === "HEAD") {
    if (typeof stream.destroy === "function") stream.destroy();
    else stream.abort?.();
    writeHead(nodeRes, status, statusText, headers);
    return endNodeResponse(nodeRes);
  }
  if (typeof stream.on !== "function" || typeof stream.destroy !== "function") {
    writeHead(nodeRes, status, statusText, headers);
    stream.pipe(nodeRes);
    return new Promise((resolve) => nodeRes.on("close", resolve));
  }
  if (stream.destroyed) {
    writeHead(nodeRes, 500, "Internal Server Error", []);
    return endNodeResponse(nodeRes);
  }
  return new Promise((resolve) => {
    function cleanup() {
      stream.off("error", onEarlyError);
      stream.off("readable", onReadable);
      nodeRes.off("close", onResClose);
    }
    function onEarlyError() {
      cleanup();
      stream.destroy();
      writeHead(nodeRes, 500, "Internal Server Error", []);
      endNodeResponse(nodeRes).then(resolve);
    }
    function onReadable() {
      cleanup();
      if (nodeRes.destroyed) {
        stream.destroy();
        return resolve();
      }
      writeHead(nodeRes, status, statusText, headers);
      pipeline(stream, nodeRes).catch(() => {
      }).then(() => resolve());
    }
    function onResClose() {
      cleanup();
      stream.destroy();
      resolve();
    }
    stream.once("error", onEarlyError);
    stream.once("readable", onReadable);
    nodeRes.once("close", onResClose);
  });
}
function streamBody(stream, nodeRes) {
  if (nodeRes.destroyed) {
    stream.cancel().catch(() => {
    });
    return;
  }
  if (nodeRes.req?.method === "HEAD") {
    stream.cancel().catch(() => {
    });
    return endNodeResponse(nodeRes);
  }
  const reader = stream.getReader();
  function streamCancel(error) {
    reader.cancel(error).catch(() => {
    });
    if (error) nodeRes.destroy(error);
  }
  function streamHandle({ done, value }) {
    try {
      if (done) nodeRes.end();
      else if (nodeRes.write(value)) reader.read().then(streamHandle, streamCancel);
      else nodeRes.once("drain", () => reader.read().then(streamHandle, streamCancel));
    } catch (error) {
      streamCancel(error instanceof Error ? error : void 0);
    }
  }
  nodeRes.on("close", streamCancel);
  nodeRes.on("error", streamCancel);
  reader.read().then(streamHandle, streamCancel);
  return reader.closed.catch(streamCancel).finally(() => {
    nodeRes.off("close", streamCancel);
    nodeRes.off("error", streamCancel);
  });
}
var NodeRequestURL = class extends FastURL$2 {
  constructor({ req, hops = 0 }) {
    const path = req.url || "/";
    const trusted = hops > 0;
    const forwardedHost = forwardedHopValue(req.headers["x-forwarded-host"], hops);
    let host = (forwardedHost && HOST_RE.test(forwardedHost) ? forwardedHost : void 0) || req.headers.host || req.headers[":authority"];
    if (host && !HOST_RE.test(host)) host = "_invalid_";
    else if (!host) {
      if (req.socket) host = `${req.socket.localFamily === "IPv6" ? "[" + req.socket.localAddress + "]" : req.socket.localAddress}:${req.socket?.localPort || "80"}`;
      else host = "localhost";
    }
    const forwardedProto = forwardedHopValue(req.headers["x-forwarded-proto"], hops);
    const protocol = req.socket?.encrypted || forwardedProto === "https" || trusted && req.headers[":scheme"] === "https" ? "https:" : "http:";
    if (path[0] === "/") {
      const qIndex = path.indexOf("?");
      super({
        protocol,
        host,
        pathname: qIndex === -1 ? path : path.slice(0, qIndex) || "/",
        search: qIndex === -1 ? "" : path.slice(qIndex) || ""
      });
    } else if (path === "*") super({
      protocol,
      host,
      pathname: "/*",
      search: ""
    });
    else {
      const target = URL.canParse(path) ? new URL(path) : void 0;
      if (target) {
        const targetHost = target.host;
        const targetPath = target.pathname;
        super({
          protocol,
          host: targetHost ? HOST_RE.test(targetHost) ? targetHost : "_invalid_" : host,
          pathname: targetPath ? targetPath[0] === "/" ? targetPath : `/${targetPath}` : "/",
          search: target.search
        });
      } else super({
        protocol,
        host,
        pathname: "/",
        search: ""
      });
    }
  }
};
function isValidAbsoluteForm(target) {
  if (!URL.canParse(target)) return false;
  const url = new URL(target);
  return (url.protocol === "http:" || url.protocol === "https:") && url.host !== "";
}
const _nonJoinedHeaders = /* @__PURE__ */ new Set([
  "age",
  "authorization",
  "content-length",
  "content-type",
  "etag",
  "expires",
  "from",
  "host",
  "if-modified-since",
  "if-unmodified-since",
  "last-modified",
  "location",
  "max-forwards",
  "proxy-authorization",
  "referer",
  "retry-after",
  "server",
  "user-agent"
]);
const _validHeaderNameRE = /^[!#$%&'*+\-.^_`|~\dA-Za-z]+$/;
function _isRepeated(rawHeaders, lowerName) {
  let seen = false;
  for (let i = 0; i < rawHeaders.length; i += 2) {
    const key = rawHeaders[i];
    if (key.length === lowerName.length && key.toLowerCase() === lowerName) {
      if (seen) return true;
      seen = true;
    }
  }
  return false;
}
const NodeRequestHeaders = /* @__PURE__ */ (() => {
  const NativeHeaders = globalThis.Headers;
  class Headers2 {
    #req;
    #headers;
    constructor(req) {
      this.#req = req;
    }
    static [Symbol.hasInstance](val) {
      return val instanceof NativeHeaders;
    }
    _adopt(headers) {
      this.#headers = headers;
    }
    get _headers() {
      if (!this.#headers) {
        const headers = new NativeHeaders();
        const rawHeaders = this.#req.rawHeaders;
        const len = rawHeaders.length;
        for (let i = 0; i < len; i += 2) {
          const key = rawHeaders[i];
          if (key.charCodeAt(0) === 58) continue;
          const value = rawHeaders[i + 1];
          headers.append(key, value);
        }
        this.#headers = headers;
      }
      return this.#headers;
    }
    get(name) {
      if (this.#headers) return this.#headers.get(name);
      const lower = name.toLowerCase();
      if (lower.charCodeAt(0) === 58) return this._headers.get(name);
      const value = this.#req.headers[lower];
      if (typeof value === "string") return _nonJoinedHeaders.has(lower) && _isRepeated(this.#req.rawHeaders, lower) ? this._headers.get(name) : value;
      if (Array.isArray(value)) return value.join(", ");
      return lower !== "__proto__" && _validHeaderNameRE.test(name) ? null : this._headers.get(name);
    }
    has(name) {
      if (this.#headers) return this.#headers.has(name);
      const lower = name.toLowerCase();
      if (lower.charCodeAt(0) === 58) return this._headers.has(name);
      if (Object.hasOwn(this.#req.headers, lower)) return true;
      return lower !== "__proto__" && _validHeaderNameRE.test(name) ? false : this._headers.has(name);
    }
    getSetCookie() {
      if (this.#headers) return this.#headers.getSetCookie();
      const value = this.#req.headers["set-cookie"];
      return Array.isArray(value) ? value.slice() : value ? [value] : [];
    }
    entries() {
      return this._headers.entries();
    }
    [Symbol.iterator]() {
      return this.entries();
    }
  }
  lazyInherit$2(Headers2.prototype, NativeHeaders.prototype, "_headers");
  Object.setPrototypeOf(Headers2, NativeHeaders);
  Object.setPrototypeOf(Headers2.prototype, NativeHeaders.prototype);
  return Headers2;
})();
const kNativeRequest = /* @__PURE__ */ Symbol.for("srvx.nativeRequest");
function bodyUnusable() {
  return /* @__PURE__ */ new TypeError("Body is unusable: Body has already been read");
}
function abortError() {
  return new DOMException("The request was aborted.", "AbortError");
}
function erroredStream(error) {
  return new ReadableStream({ start(controller) {
    controller.error(error);
  } });
}
function isClientGone(req) {
  return req.aborted || !!req.errored || req.destroyed && !req.complete;
}
function isBodySourceFinished(req) {
  return isClientGone(req) || req.destroyed || req.readableEnded;
}
const NodeRequest = /* @__PURE__ */ (() => {
  const NativeRequest = getNativeRequest();
  class Request {
    runtime;
    waitUntil;
    #req;
    #url;
    #bodyStream;
    #bodyUsed = false;
    #request;
    #headers;
    #abortController;
    #maxRequestBodySize;
    #trustProxy;
    #ip;
    #ipResolved = false;
    #remoteAddress;
    #remoteResolved = false;
    #hops;
    constructor(ctx) {
      this.#req = ctx.req;
      this.#maxRequestBodySize = ctx.maxRequestBodySize;
      this.#trustProxy = ctx.trustProxy;
      this.runtime = {
        name: "node",
        node: ctx
      };
    }
    static [Symbol.hasInstance](val) {
      return val instanceof NativeRequest;
    }
    #remoteAddr() {
      if (!this.#remoteResolved) {
        this.#remoteResolved = true;
        this.#remoteAddress = this.#req.socket?.remoteAddress;
      }
      return this.#remoteAddress;
    }
    #resolveHops() {
      if (this.#hops === void 0) this.#hops = trustedHops(this.#trustProxy, this.#remoteAddr(), this.#req.headers["x-forwarded-for"]);
      return this.#hops;
    }
    get ip() {
      if (this.#ipResolved) return this.#ip;
      this.#ipResolved = true;
      return this.#ip = resolveClientIP(this.#trustProxy, this.#remoteAddr(), this.#req.headers["x-forwarded-for"]);
    }
    get method() {
      if (this.#request) return this.#request.method;
      return this.#req.method || "GET";
    }
    get _url() {
      return this.#url ||= new NodeRequestURL({
        req: this.#req,
        hops: this.#resolveHops()
      });
    }
    set _url(url) {
      this.#url = url;
    }
    get url() {
      if (this.#request) return this.#request.url;
      return this._url.href;
    }
    get headers() {
      return this.#headers ||= new NodeRequestHeaders(this.#req);
    }
    get _abortController() {
      if (!this.#abortController) {
        this.#abortController = new AbortController();
        const { req, res } = this.runtime.node;
        const abortController = this.#abortController;
        const abort = (err) => abortController.abort?.(err);
        if (res) {
          const onClose = () => {
            const reqError = req.errored;
            if (reqError) abort(reqError);
            else if (!res.writableEnded) abort();
          };
          res.once("close", onClose);
          if (res.destroyed || isClientGone(req)) onClose();
        } else {
          const onClose = () => {
            if (!req.complete || req.aborted) abort();
          };
          req.once("close", onClose);
          if (isClientGone(req)) onClose();
        }
      }
      return this.#abortController;
    }
    get signal() {
      return this.#request ? this.#request.signal : this._abortController.signal;
    }
    #hasBody() {
      const method = this.method;
      return method !== "GET" && method !== "HEAD";
    }
    get body() {
      if (this.#request) return this.#request.body;
      if (this.#bodyStream === void 0) {
        let stream = null;
        if (this.#hasBody() && !this.#bodyUsed) {
          if (isBodySourceFinished(this.#req)) stream = erroredStream(this.#bodyError());
          else stream = Readable.toWeb(this.#req);
        }
        if (stream && this.#maxRequestBodySize !== void 0) stream = limitBodyStream(stream, this.#maxRequestBodySize);
        this.#bodyStream = stream;
      }
      return this.#bodyStream;
    }
    get bodyUsed() {
      if (this.#isBodyUsed()) return true;
      return this.#request ? this.#request.bodyUsed : false;
    }
    #isBodyUsed() {
      if (!this.#bodyUsed && this.#bodyStream && Readable.isDisturbed(this.#bodyStream)) this.#bodyUsed = true;
      return this.#bodyUsed;
    }
    #bodyError() {
      const signal = this._abortController.signal;
      if (signal.aborted) return signal.reason;
      return this.#req.errored || (isClientGone(this.#req) ? abortError() : bodyUnusable());
    }
    #readBuffered() {
      if ("rawBody" in this.#req && Buffer.isBuffer(this.#req.rawBody)) return readBody(this.#req, this.#maxRequestBodySize);
      if (isBodySourceFinished(this.#req)) return Promise.reject(this.#bodyError());
      return readBody(this.#req, this.#maxRequestBodySize);
    }
    text() {
      if (this.#isBodyUsed()) return Promise.reject(bodyUnusable());
      if (this.#request) return this.#request.text();
      if (!this.#hasBody()) return Promise.resolve("");
      this.#bodyUsed = true;
      if (this.#bodyStream !== void 0) try {
        return new Response(this.#bodyStream).text();
      } catch (error) {
        return Promise.reject(error);
      }
      return this.#readBuffered().then((buf) => buf.toString());
    }
    json() {
      if (this.#isBodyUsed()) return Promise.reject(bodyUnusable());
      if (this.#request) return this.#request.json();
      if (!this.#hasBody()) return Promise.resolve().then(() => JSON.parse(""));
      this.#bodyUsed = true;
      if (this.#bodyStream !== void 0) try {
        return new Response(this.#bodyStream).json();
      } catch (error) {
        return Promise.reject(error);
      }
      return this.#readBuffered().then((buf) => JSON.parse(buf.toString()));
    }
    arrayBuffer() {
      return this.#consumeNative("arrayBuffer");
    }
    bytes() {
      return this.#consumeNative("bytes");
    }
    blob() {
      return this.#consumeNative("blob");
    }
    formData() {
      return this.#consumeNative("formData");
    }
    #consumeNative(method) {
      if (this.#isBodyUsed()) return Promise.reject(bodyUnusable());
      try {
        return this._request[method]();
      } catch (error) {
        return Promise.reject(error);
      }
    }
    get _request() {
      if (!this.#request) {
        const body = this.#isBodyUsed() ? null : this.body;
        this.#request = new NativeRequest(this.url, {
          method: this.method,
          headers: this.headers,
          signal: this._abortController.signal,
          body,
          duplex: body ? "half" : void 0
        });
        this.#headers._adopt(this.#request.headers);
        this.#bodyStream = void 0;
      }
      return this.#request;
    }
  }
  lazyInherit$2(Request.prototype, NativeRequest.prototype, "_request");
  Object.setPrototypeOf(Request.prototype, NativeRequest.prototype);
  return Request;
})();
function readBody(req, maxRequestBodySize) {
  if ("rawBody" in req && Buffer.isBuffer(req.rawBody)) {
    if (maxRequestBodySize !== void 0 && req.rawBody.length > maxRequestBodySize) return Promise.reject(createBodyTooLargeError(maxRequestBodySize));
    return Promise.resolve(req.rawBody);
  }
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    const cleanup = () => {
      req.off("data", onData);
      req.off("end", onEnd);
      req.off("error", onError);
      req.off("close", onClose);
    };
    const onData = (chunk) => {
      if (maxRequestBodySize !== void 0) {
        size += chunk.length;
        if (size > maxRequestBodySize) {
          cleanup();
          req.pause?.();
          reject(createBodyTooLargeError(maxRequestBodySize));
          return;
        }
      }
      chunks.push(chunk);
    };
    const onError = (err) => {
      cleanup();
      reject(err);
    };
    const onEnd = () => {
      cleanup();
      if (isClientGone(req)) {
        reject(req.errored || abortError());
        return;
      }
      resolve(chunks.length === 1 ? chunks[0] : Buffer.concat(chunks));
    };
    const onClose = () => {
      cleanup();
      reject(req.errored || abortError());
    };
    req.on("data", onData).once("end", onEnd).once("error", onError).once("close", onClose);
  });
}
function getNativeRequest() {
  let R = globalThis[kNativeRequest] || globalThis.Request;
  while (R?._srvx) R = Object.getPrototypeOf(R);
  return globalThis[kNativeRequest] ??= R;
}
const NodeResponse$2 = /* @__PURE__ */ (() => {
  const NativeResponse = globalThis.Response;
  class NodeResponse2 {
    #body;
    #init;
    #headers;
    #response;
    constructor(body, init) {
      this.#body = body;
      this.#init = init;
    }
    static [Symbol.hasInstance](val) {
      return val instanceof NativeResponse;
    }
    static json(data, init) {
      const body = JSON.stringify(data);
      if (body === void 0) throw new TypeError("Value is not JSON serializable");
      let headers = init?.headers;
      if (!headers) headers = { "content-type": "application/json" };
      else {
        const merged = new Headers(headers);
        if (!merged.has("content-type")) merged.set("content-type", "application/json");
        headers = merged;
      }
      return new NodeResponse2(body, init ? {
        ...init,
        headers
      } : { headers });
    }
    get status() {
      return this.#response?.status || this.#init?.status || 200;
    }
    get statusText() {
      return this.#response?.statusText || this.#init?.statusText || "";
    }
    get headers() {
      if (this.#response) return this.#response.headers;
      if (this.#headers) return this.#headers;
      return this.#headers = new Headers(this.#init?.headers);
    }
    get ok() {
      if (this.#response) return this.#response.ok;
      const status = this.status;
      return status >= 200 && status < 300;
    }
    get _response() {
      if (this.#response) return this.#response;
      let body = this.#body;
      if (body && typeof body.pipe === "function" && !(body instanceof Readable)) {
        const stream = new PassThrough();
        body.pipe(stream);
        const abort = body.abort;
        if (abort) stream.once("close", () => abort());
        body = stream;
      }
      this.#response = new NativeResponse(body, this.#headers ? {
        ...this.#init,
        headers: this.#headers
      } : this.#init);
      this.#init = void 0;
      this.#headers = void 0;
      this.#body = void 0;
      return this.#response;
    }
    _toNodeResponse() {
      const status = this.status;
      const statusText = this.statusText;
      let body;
      let contentType;
      let contentLength;
      if (this.#response) body = this.#response.body;
      else if (this.#body != null) {
        if (this.#body instanceof ReadableStream) body = this.#body;
        else if (typeof this.#body === "string") {
          body = this.#body;
          contentType = "text/plain; charset=UTF-8";
          contentLength = Buffer.byteLength(this.#body);
        } else if (this.#body instanceof ArrayBuffer) {
          body = Buffer.from(this.#body);
          contentLength = this.#body.byteLength;
        } else if (this.#body instanceof Uint8Array) {
          body = this.#body;
          contentLength = this.#body.byteLength;
        } else if (this.#body instanceof DataView) {
          body = Buffer.from(this.#body.buffer, this.#body.byteOffset, this.#body.byteLength);
          contentLength = this.#body.byteLength;
        } else if (this.#body instanceof Blob) {
          body = this.#body.stream();
          contentType = this.#body.type;
          contentLength = this.#body.size;
        } else if (typeof this.#body.pipe === "function") body = this.#body;
        else body = this._response.body;
      }
      const headers = [];
      const initHeaders = this.#init?.headers;
      const headerEntries = this.#response?.headers || this.#headers || (initHeaders ? Array.isArray(initHeaders) ? initHeaders : initHeaders?.entries ? initHeaders.entries() : Object.entries(initHeaders) : void 0);
      let hasContentTypeHeader;
      let hasContentLength;
      if (headerEntries) for (const [key, value] of headerEntries) {
        const lowerKey = typeof key === "string" ? key.toLowerCase() : String(key);
        if (Array.isArray(value)) for (const v of value) headers.push(lowerKey, v);
        else headers.push(lowerKey, value);
        if (lowerKey === "content-type") hasContentTypeHeader = true;
        else if (lowerKey === "content-length") hasContentLength = true;
      }
      if (contentType && !hasContentTypeHeader) headers.push("content-type", contentType);
      if (contentLength != null && !hasContentLength) headers.push("content-length", String(contentLength));
      this.#init = void 0;
      this.#headers = void 0;
      this.#response = void 0;
      this.#body = void 0;
      return {
        status,
        statusText,
        headers,
        body
      };
    }
  }
  lazyInherit$2(NodeResponse2.prototype, NativeResponse.prototype, "_response");
  Object.setPrototypeOf(NodeResponse2, NativeResponse);
  Object.setPrototypeOf(NodeResponse2.prototype, NativeResponse.prototype);
  return NodeResponse2;
})();
function serve(options) {
  return new NodeServer(options);
}
var NodeServer = class {
  runtime = "node";
  options;
  node;
  serveOptions;
  fetch;
  waitUntil;
  #isSecure;
  #listeningPromise;
  #listenError;
  #listenErrorObserved;
  #wait;
  constructor(options) {
    this.options = {
      ...options,
      middleware: [...options.middleware || []]
    };
    for (const plugin of options.plugins || []) plugin(this);
    errorPlugin(this);
    const fetchHandler = this.fetch = wrapFetch(this);
    const handler = (nodeReq, nodeRes) => {
      const reqUrl = nodeReq.url;
      if (reqUrl && reqUrl[0] !== "/" && reqUrl !== "*" && !isValidAbsoluteForm(reqUrl)) {
        nodeRes.statusCode = 400;
        nodeRes.end();
        return;
      }
      const request = new NodeRequest({
        req: nodeReq,
        res: nodeRes,
        maxRequestBodySize: this.options.maxRequestBodySize,
        trustProxy: this.options.trustProxy
      });
      request.waitUntil = this.#wait?.waitUntil;
      let res;
      try {
        res = fetchHandler(request);
      } catch (error) {
        return sendErrorResponse(nodeRes, error, this.options.silent);
      }
      return typeof res?.then === "function" ? res.then((resolvedRes) => sendNodeResponseDetached(nodeRes, resolvedRes, this.options.silent), (error) => sendErrorResponse(nodeRes, error, this.options.silent)) : sendNodeResponseDetached(nodeRes, res, this.options.silent);
    };
    this.node = {
      handler,
      server: void 0
    };
    const loader = globalThis.__srvxLoader__;
    if (loader) {
      loader({ server: this });
      return;
    }
    gracefulShutdownPlugin(this);
    this.#wait = createWaitUntil();
    this.waitUntil = this.#wait.waitUntil;
    const tls = resolveTLSOptions(this.options);
    const { port, hostname: host } = resolvePortAndHost(this.options);
    this.serveOptions = {
      port,
      host,
      exclusive: !this.options.reusePort,
      reusePort: this.options.reusePort,
      ...tls,
      ...this.options.node
    };
    let server;
    this.#isSecure = !!this.serveOptions.cert && this.options.protocol !== "http";
    if (this.options.node?.http2 ?? this.#isSecure) {
      if (this.#isSecure) server = nodeHTTP2.createSecureServer({
        allowHTTP1: true,
        ...this.serveOptions
      }, handler);
      else throw new Error("node.http2 option requires tls certificate!");
    } else if (this.#isSecure) server = nodeHTTPS.createServer(this.serveOptions, handler);
    else server = nodeHTTP.createServer(this.serveOptions, handler);
    this.node.server = server;
    if (!options.manual) this.serve().catch((error) => this.#reportUnobservedListenError(error));
  }
  #reportUnobservedListenError(error) {
    if (this.#listenErrorObserved) return;
    if (!this.options.silent) console.error("[srvx] Failed to start server:", error);
    const process2 = globalThis.process;
    if (process2 && !process2.exitCode) process2.exitCode = 1;
  }
  serve() {
    if (this.#listeningPromise) return this.#listeningPromise.then(() => this);
    const server = this.node?.server;
    if (!server) return Promise.reject(/* @__PURE__ */ new Error("Server not initialized"));
    this.#listenError = void 0;
    this.#listeningPromise = new Promise((resolve, reject) => {
      const onError = (error) => {
        server.off("listening", onListening);
        this.#listenError = error;
        this.#listeningPromise = void 0;
        reject(error);
      };
      const onListening = () => {
        server.off("error", onError);
        printListening(this.options, this.url);
        resolve();
      };
      server.once("error", onError);
      server.once("listening", onListening);
      server.listen(this.serveOptions);
    });
    return this.#listeningPromise.then(() => this);
  }
  get url() {
    const addr = this.node?.server?.address();
    if (!addr) return;
    return typeof addr === "string" ? addr : fmtURL(addr.address, addr.port, this.#isSecure);
  }
  ready() {
    this.#listenErrorObserved = true;
    if (this.#listenError) return Promise.reject(this.#listenError);
    return Promise.resolve(this.#listeningPromise).then(() => this);
  }
  async close(closeAll) {
    await Promise.all([this.#wait?.wait(), new Promise((resolve, reject) => {
      const server = this.node?.server;
      if (server && closeAll && "closeAllConnections" in server) server.closeAllConnections();
      if (!server || !server.listening) return resolve();
      server.close((error) => error ? reject(error) : resolve());
    })]);
  }
};
function lazyInherit$1(target, source, sourceKey) {
  for (const key of [...Object.getOwnPropertyNames(source), ...Object.getOwnPropertySymbols(source)]) {
    if (key === "constructor") continue;
    const targetDesc = Object.getOwnPropertyDescriptor(target, key);
    const desc = Object.getOwnPropertyDescriptor(source, key);
    let modified = false;
    if (desc.get) {
      modified = true;
      desc.get = targetDesc?.get || function() {
        return this[sourceKey][key];
      };
    }
    if (desc.set) {
      modified = true;
      desc.set = targetDesc?.set || function(value) {
        this[sourceKey][key] = value;
      };
    }
    if (!targetDesc?.value && typeof desc.value === "function") {
      modified = true;
      desc.value = function(...args) {
        return this[sourceKey][key](...args);
      };
    }
    if (modified) Object.defineProperty(target, key, desc);
  }
}
const _needsNormRE$1 = /(?:(?:^|\/)(?:\.|\.\.|%2e|%2e\.|\.%2e|%2e%2e)(?:\/|$))|[\\^#"<>{}`\x00-\x20\x7f-\uffff]/i;
const _searchNeedsNormRE$1 = /[#"'<>\x00-\x20\x7f-\uffff]/;
const FastURL$1 = /* @__PURE__ */ (() => {
  const NativeURL = globalThis.URL;
  const NativeSearchParams = globalThis.URLSearchParams;
  const FastURLSearchParams = class URLSearchParams {
    #owner;
    #params;
    constructor(owner) {
      this.#owner = owner;
    }
    static [Symbol.hasInstance](val) {
      return val instanceof NativeSearchParams;
    }
    _adopt(params) {
      this.#params = params;
    }
    get _params() {
      if (!this.#params) {
        const search = this.#owner.search;
        this.#params ??= new NativeSearchParams(search);
      }
      return this.#params;
    }
    #mutable() {
      this.#owner._url;
      return this.#params;
    }
    append(name, value) {
      this.#mutable().append(name, value);
    }
    set(name, value) {
      this.#mutable().set(name, value);
    }
    delete(name, value) {
      this.#mutable().delete(name, value);
    }
    sort() {
      this.#mutable().sort();
    }
  };
  lazyInherit$1(FastURLSearchParams.prototype, NativeSearchParams.prototype, "_params");
  Object.setPrototypeOf(FastURLSearchParams.prototype, NativeSearchParams.prototype);
  Object.setPrototypeOf(FastURLSearchParams, NativeSearchParams);
  const FastURL2 = class URL {
    #url;
    #href;
    #protocol;
    #host;
    #pathname;
    #search;
    #searchParams;
    #pos;
    constructor(url) {
      if (typeof url === "string") {
        const isOriginForm = url[0] === "/";
        if (isOriginForm && !_searchNeedsNormRE$1.test(url)) this.#href = `http://localhost${url}`;
        else this.#url = new NativeURL(isOriginForm ? `http://localhost${url}` : url);
      } else if (_needsNormRE$1.test(url.pathname) || url.search && _searchNeedsNormRE$1.test(url.search)) this.#url = new NativeURL(`${url.protocol || "http:"}//${url.host || "localhost"}${url.pathname}${url.search || ""}`);
      else {
        this.#protocol = url.protocol;
        this.#host = url.host;
        this.#pathname = url.pathname;
        this.#search = url.search;
      }
    }
    static [Symbol.hasInstance](val) {
      return val instanceof NativeURL;
    }
    get _url() {
      if (this.#url) return this.#url;
      this.#url = new NativeURL(this.href);
      this.#href = void 0;
      this.#protocol = void 0;
      this.#host = void 0;
      this.#pathname = void 0;
      this.#search = void 0;
      this.#pos = void 0;
      this.#searchParams?._adopt(this.#url.searchParams);
      return this.#url;
    }
    get href() {
      if (this.#url) return this.#url.href;
      if (!this.#href) this.#href = `${this.#protocol || "http:"}//${this.#host || "localhost"}${this.#pathname || "/"}${this.#search || ""}`;
      return this.#href;
    }
    #getPos() {
      if (!this.#pos) {
        const url = this.href;
        const protoIndex = url.indexOf("://");
        const pathnameIndex = protoIndex === -1 ? -1 : url.indexOf("/", protoIndex + 4);
        const qIndex = pathnameIndex === -1 ? -1 : url.indexOf("?", pathnameIndex);
        this.#pos = [
          protoIndex,
          pathnameIndex,
          qIndex
        ];
      }
      return this.#pos;
    }
    get pathname() {
      if (this.#url) return this.#url.pathname;
      if (this.#pathname === void 0) {
        const [, pathnameIndex, queryIndex] = this.#getPos();
        if (pathnameIndex === -1) return this._url.pathname;
        this.#pathname = this.href.slice(pathnameIndex, queryIndex === -1 ? void 0 : queryIndex);
      }
      return this.#pathname;
    }
    get search() {
      if (this.#url) return this.#url.search;
      if (this.#search === void 0) {
        const [, pathnameIndex, queryIndex] = this.#getPos();
        if (pathnameIndex === -1) return this._url.search;
        const url = this.href;
        this.#search = queryIndex === -1 || queryIndex === url.length - 1 ? "" : url.slice(queryIndex);
      }
      return this.#search;
    }
    get searchParams() {
      if (this.#searchParams) return this.#searchParams;
      if (this.#url) return this.#url.searchParams;
      return this.#searchParams = new FastURLSearchParams(this);
    }
    get protocol() {
      if (this.#url) return this.#url.protocol;
      if (this.#protocol === void 0) {
        const [protocolIndex] = this.#getPos();
        if (protocolIndex === -1) return this._url.protocol;
        const url = this.href;
        this.#protocol = url.slice(0, protocolIndex + 1);
      }
      return this.#protocol;
    }
    get hash() {
      if (this.#url) return this.#url.hash;
      return "";
    }
    toString() {
      return this.href;
    }
    toJSON() {
      return this.href;
    }
  };
  lazyInherit$1(FastURL2.prototype, NativeURL.prototype, "_url");
  Object.setPrototypeOf(FastURL2.prototype, NativeURL.prototype);
  Object.setPrototypeOf(FastURL2, NativeURL);
  return FastURL2;
})();
const NodeResponse$1 = /* @__PURE__ */ (() => {
  const NativeResponse = globalThis.Response;
  class NodeResponse2 {
    #body;
    #init;
    #headers;
    #response;
    constructor(body, init) {
      this.#body = body;
      this.#init = init;
    }
    static [Symbol.hasInstance](val) {
      return val instanceof NativeResponse;
    }
    static json(data, init) {
      const body = JSON.stringify(data);
      if (body === void 0) throw new TypeError("Value is not JSON serializable");
      let headers = init?.headers;
      if (!headers) headers = { "content-type": "application/json" };
      else {
        const merged = new Headers(headers);
        if (!merged.has("content-type")) merged.set("content-type", "application/json");
        headers = merged;
      }
      return new NodeResponse2(body, init ? {
        ...init,
        headers
      } : { headers });
    }
    get status() {
      return this.#response?.status || this.#init?.status || 200;
    }
    get statusText() {
      return this.#response?.statusText || this.#init?.statusText || "";
    }
    get headers() {
      if (this.#response) return this.#response.headers;
      if (this.#headers) return this.#headers;
      return this.#headers = new Headers(this.#init?.headers);
    }
    get ok() {
      if (this.#response) return this.#response.ok;
      const status = this.status;
      return status >= 200 && status < 300;
    }
    get _response() {
      if (this.#response) return this.#response;
      let body = this.#body;
      if (body && typeof body.pipe === "function" && !(body instanceof Readable)) {
        const stream = new PassThrough();
        body.pipe(stream);
        const abort = body.abort;
        if (abort) stream.once("close", () => abort());
        body = stream;
      }
      this.#response = new NativeResponse(body, this.#headers ? {
        ...this.#init,
        headers: this.#headers
      } : this.#init);
      this.#init = void 0;
      this.#headers = void 0;
      this.#body = void 0;
      return this.#response;
    }
    _toNodeResponse() {
      const status = this.status;
      const statusText = this.statusText;
      let body;
      let contentType;
      let contentLength;
      if (this.#response) body = this.#response.body;
      else if (this.#body != null) {
        if (this.#body instanceof ReadableStream) body = this.#body;
        else if (typeof this.#body === "string") {
          body = this.#body;
          contentType = "text/plain; charset=UTF-8";
          contentLength = Buffer.byteLength(this.#body);
        } else if (this.#body instanceof ArrayBuffer) {
          body = Buffer.from(this.#body);
          contentLength = this.#body.byteLength;
        } else if (this.#body instanceof Uint8Array) {
          body = this.#body;
          contentLength = this.#body.byteLength;
        } else if (this.#body instanceof DataView) {
          body = Buffer.from(this.#body.buffer, this.#body.byteOffset, this.#body.byteLength);
          contentLength = this.#body.byteLength;
        } else if (this.#body instanceof Blob) {
          body = this.#body.stream();
          contentType = this.#body.type;
          contentLength = this.#body.size;
        } else if (typeof this.#body.pipe === "function") body = this.#body;
        else body = this._response.body;
      }
      const headers = [];
      const initHeaders = this.#init?.headers;
      const headerEntries = this.#response?.headers || this.#headers || (initHeaders ? Array.isArray(initHeaders) ? initHeaders : initHeaders?.entries ? initHeaders.entries() : Object.entries(initHeaders) : void 0);
      let hasContentTypeHeader;
      let hasContentLength;
      if (headerEntries) for (const [key, value] of headerEntries) {
        const lowerKey = typeof key === "string" ? key.toLowerCase() : String(key);
        if (Array.isArray(value)) for (const v of value) headers.push(lowerKey, v);
        else headers.push(lowerKey, value);
        if (lowerKey === "content-type") hasContentTypeHeader = true;
        else if (lowerKey === "content-length") hasContentLength = true;
      }
      if (contentType && !hasContentTypeHeader) headers.push("content-type", contentType);
      if (contentLength != null && !hasContentLength) headers.push("content-length", String(contentLength));
      this.#init = void 0;
      this.#headers = void 0;
      this.#response = void 0;
      this.#body = void 0;
      return {
        status,
        statusText,
        headers,
        body
      };
    }
  }
  lazyInherit$1(NodeResponse2.prototype, NativeResponse.prototype, "_response");
  Object.setPrototypeOf(NodeResponse2, NativeResponse);
  Object.setPrototypeOf(NodeResponse2.prototype, NativeResponse.prototype);
  return NodeResponse2;
})();
function lazyInherit(target, source, sourceKey) {
  for (const key of [...Object.getOwnPropertyNames(source), ...Object.getOwnPropertySymbols(source)]) {
    if (key === "constructor") continue;
    const targetDesc = Object.getOwnPropertyDescriptor(target, key);
    const desc = Object.getOwnPropertyDescriptor(source, key);
    let modified = false;
    if (desc.get) {
      modified = true;
      desc.get = targetDesc?.get || function() {
        return this[sourceKey][key];
      };
    }
    if (desc.set) {
      modified = true;
      desc.set = targetDesc?.set || function(value) {
        this[sourceKey][key] = value;
      };
    }
    if (!targetDesc?.value && typeof desc.value === "function") {
      modified = true;
      desc.value = function(...args) {
        return this[sourceKey][key](...args);
      };
    }
    if (modified) Object.defineProperty(target, key, desc);
  }
}
const _needsNormRE = /(?:(?:^|\/)(?:\.|\.\.|%2e|%2e\.|\.%2e|%2e%2e)(?:\/|$))|[\\^#"<>{}`\x80-\uffff]/i;
const _searchNeedsNormRE = /[#"'<>]/;
const FastURL = /* @__PURE__ */ (() => {
  const NativeURL = globalThis.URL;
  const FastURL2 = class URL {
    #url;
    #href;
    #protocol;
    #host;
    #pathname;
    #search;
    #searchParams;
    #pos;
    constructor(url) {
      if (typeof url === "string") {
        const isOriginForm = url[0] === "/";
        if (isOriginForm && !_searchNeedsNormRE.test(url)) this.#href = url;
        else this.#url = new NativeURL(isOriginForm ? `http://localhost${url}` : url);
      } else if (_needsNormRE.test(url.pathname) || url.search && _searchNeedsNormRE.test(url.search)) this.#url = new NativeURL(`${url.protocol || "http:"}//${url.host || "localhost"}${url.pathname}${url.search || ""}`);
      else {
        this.#protocol = url.protocol;
        this.#host = url.host;
        this.#pathname = url.pathname;
        this.#search = url.search;
      }
    }
    static [Symbol.hasInstance](val) {
      return val instanceof NativeURL;
    }
    get _url() {
      if (this.#url) return this.#url;
      this.#url = new NativeURL(this.href);
      this.#href = void 0;
      this.#protocol = void 0;
      this.#host = void 0;
      this.#pathname = void 0;
      this.#search = void 0;
      this.#searchParams = void 0;
      this.#pos = void 0;
      return this.#url;
    }
    get href() {
      if (this.#url) return this.#url.href;
      if (!this.#href) this.#href = `${this.#protocol || "http:"}//${this.#host || "localhost"}${this.#pathname || "/"}${this.#search || ""}`;
      return this.#href;
    }
    #getPos() {
      if (!this.#pos) {
        const url = this.href;
        const protoIndex = url.indexOf("://");
        const pathnameIndex = protoIndex === -1 ? -1 : url.indexOf("/", protoIndex + 4);
        const qIndex = pathnameIndex === -1 ? -1 : url.indexOf("?", pathnameIndex);
        this.#pos = [
          protoIndex,
          pathnameIndex,
          qIndex
        ];
      }
      return this.#pos;
    }
    get pathname() {
      if (this.#url) return this.#url.pathname;
      if (this.#pathname === void 0) {
        const [, pathnameIndex, queryIndex] = this.#getPos();
        if (pathnameIndex === -1) return this._url.pathname;
        this.#pathname = this.href.slice(pathnameIndex, queryIndex === -1 ? void 0 : queryIndex);
      }
      return this.#pathname;
    }
    get search() {
      if (this.#url) return this.#url.search;
      if (this.#search === void 0) {
        const [, pathnameIndex, queryIndex] = this.#getPos();
        if (pathnameIndex === -1) return this._url.search;
        const url = this.href;
        this.#search = queryIndex === -1 || queryIndex === url.length - 1 ? "" : url.slice(queryIndex);
      }
      return this.#search;
    }
    get searchParams() {
      if (this.#url) return this.#url.searchParams;
      if (!this.#searchParams) this.#searchParams = new URLSearchParams(this.search);
      return this.#searchParams;
    }
    get protocol() {
      if (this.#url) return this.#url.protocol;
      if (this.#protocol === void 0) {
        const [protocolIndex] = this.#getPos();
        if (protocolIndex === -1) return this._url.protocol;
        const url = this.href;
        this.#protocol = url.slice(0, protocolIndex + 1);
      }
      return this.#protocol;
    }
    toString() {
      return this.href;
    }
    toJSON() {
      return this.href;
    }
  };
  lazyInherit(FastURL2.prototype, NativeURL.prototype, "_url");
  Object.setPrototypeOf(FastURL2.prototype, NativeURL.prototype);
  Object.setPrototypeOf(FastURL2, NativeURL);
  return FastURL2;
})();
const NodeResponse = /* @__PURE__ */ (() => {
  const NativeResponse = globalThis.Response;
  const STATUS_CODES = globalThis.process?.getBuiltinModule?.("node:http")?.STATUS_CODES || {};
  class NodeResponse2 {
    #body;
    #init;
    #headers;
    #response;
    constructor(body, init) {
      this.#body = body;
      this.#init = init;
    }
    static [Symbol.hasInstance](val) {
      return val instanceof NativeResponse;
    }
    get status() {
      return this.#response?.status || this.#init?.status || 200;
    }
    get statusText() {
      return this.#response?.statusText || this.#init?.statusText || STATUS_CODES[this.status] || "";
    }
    get headers() {
      if (this.#response) return this.#response.headers;
      if (this.#headers) return this.#headers;
      const initHeaders = this.#init?.headers;
      return this.#headers = initHeaders instanceof Headers ? initHeaders : new Headers(initHeaders);
    }
    get ok() {
      if (this.#response) return this.#response.ok;
      const status = this.status;
      return status >= 200 && status < 300;
    }
    get _response() {
      if (this.#response) return this.#response;
      let body = this.#body;
      if (body && typeof body.pipe === "function" && !(body instanceof Readable)) {
        const stream = new PassThrough();
        body.pipe(stream);
        const abort = body.abort;
        if (abort) stream.once("close", () => abort());
        body = stream;
      }
      this.#response = new NativeResponse(body, this.#headers ? {
        ...this.#init,
        headers: this.#headers
      } : this.#init);
      this.#init = void 0;
      this.#headers = void 0;
      this.#body = void 0;
      return this.#response;
    }
    _toNodeResponse() {
      const status = this.status;
      const statusText = this.statusText;
      let body;
      let contentType;
      let contentLength;
      if (this.#response) body = this.#response.body;
      else if (this.#body) if (this.#body instanceof ReadableStream) body = this.#body;
      else if (typeof this.#body === "string") {
        body = this.#body;
        contentType = "text/plain; charset=UTF-8";
        contentLength = Buffer.byteLength(this.#body);
      } else if (this.#body instanceof ArrayBuffer) {
        body = Buffer.from(this.#body);
        contentLength = this.#body.byteLength;
      } else if (this.#body instanceof Uint8Array) {
        body = this.#body;
        contentLength = this.#body.byteLength;
      } else if (this.#body instanceof DataView) {
        body = Buffer.from(this.#body.buffer);
        contentLength = this.#body.byteLength;
      } else if (this.#body instanceof Blob) {
        body = this.#body.stream();
        contentType = this.#body.type;
        contentLength = this.#body.size;
      } else if (typeof this.#body.pipe === "function") body = this.#body;
      else body = this._response.body;
      const headers = [];
      const initHeaders = this.#init?.headers;
      const headerEntries = this.#response?.headers || this.#headers || (initHeaders ? Array.isArray(initHeaders) ? initHeaders : initHeaders?.entries ? initHeaders.entries() : Object.entries(initHeaders) : void 0);
      let hasContentTypeHeader;
      let hasContentLength;
      if (headerEntries) for (const [key, value] of headerEntries) {
        const lowerKey = typeof key === "string" ? key.toLowerCase() : String(key);
        if (Array.isArray(value)) for (const v of value) headers.push(lowerKey, v);
        else headers.push(lowerKey, value);
        if (lowerKey === "content-type") hasContentTypeHeader = true;
        else if (lowerKey === "content-length") hasContentLength = true;
      }
      if (contentType && !hasContentTypeHeader) headers.push("content-type", contentType);
      if (contentLength && !hasContentLength) headers.push("content-length", String(contentLength));
      this.#init = void 0;
      this.#headers = void 0;
      this.#response = void 0;
      this.#body = void 0;
      return {
        status,
        statusText,
        headers,
        body
      };
    }
  }
  lazyInherit(NodeResponse2.prototype, NativeResponse.prototype, "_response");
  Object.setPrototypeOf(NodeResponse2, NativeResponse);
  Object.setPrototypeOf(NodeResponse2.prototype, NativeResponse.prototype);
  return NodeResponse2;
})();
export {
  FastURL$1 as F,
  NodeResponse$1 as N,
  FastURL as a,
  NodeResponse as b,
  NodeResponse$2 as c,
  serve as s
};
