import { c as createClient } from "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
const __vite_import_meta_env__ = { "BASE_URL": "/", "DEV": false, "MODE": "production", "PROD": true, "SSR": true, "TSS_DEV_SERVER": "false", "TSS_DEV_SSR_STYLES_BASEPATH": "/", "TSS_DEV_SSR_STYLES_ENABLED": "true", "TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false", "TSS_INLINE_CSS_ENABLED": "false", "TSS_ROUTER_BASEPATH": "", "TSS_SERVER_FN_BASE": "/_serverFn/", "VITE_SUPABASE_ANON_KEY": "sb_publishable_fEPybgejg_mSqpmlDj6rNw_7o67e7nt", "VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_fEPybgejg_mSqpmlDj6rNw_7o67e7nt", "VITE_SUPABASE_SERVICE_ROLE_KEY": "sb_secret_bO8H7fl-IXbXaKdZQU7mXw_TbEZ1ZXm", "VITE_SUPABASE_URL": "https://jjqgfjpxaxjpyohvcbfi.supabase.co", "VITE_VAPID_PUBLIC_KEY": "BP1RKVDzJaNmBtgeyIxDWTXx5TH7H96xS5VgPKMu77_ZOpsonDHctEl3xvS8DJkBOZbUHaAydwAzXdZU2hB9IRc" };
function isNewSupabaseApiKey(value) {
  return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}
function createSupabaseFetch(supabaseKey) {
  return (input, init) => {
    const headers = new Headers(
      typeof Request !== "undefined" && input instanceof Request ? input.headers : void 0
    );
    if (init?.headers) {
      new Headers(init.headers).forEach((value, key) => headers.set(key, value));
    }
    if (isNewSupabaseApiKey(supabaseKey) && headers.get("Authorization") === `Bearer ${supabaseKey}`) {
      headers.delete("Authorization");
    }
    headers.set("apikey", supabaseKey);
    return fetch(input, { ...init, headers });
  };
}
function getEnv(key) {
  try {
    const viteEnv = __vite_import_meta_env__;
    if (viteEnv?.[key]) return viteEnv[key];
  } catch {
  }
  if (typeof process !== "undefined" && process.env?.[key]) {
    return process.env[key];
  }
  if (typeof globalThis !== "undefined" && globalThis[key]) {
    return globalThis[key];
  }
  return void 0;
}
function createSupabaseClient() {
  const SUPABASE_URL = getEnv("VITE_SUPABASE_URL") || getEnv("SUPABASE_URL");
  const SUPABASE_PUBLISHABLE_KEY = getEnv("VITE_SUPABASE_PUBLISHABLE_KEY") || getEnv("VITE_SUPABASE_ANON_KEY") || getEnv("SUPABASE_PUBLISHABLE_KEY") || getEnv("SUPABASE_ANON_KEY");
  console.log("[Supabase] Env check:", {
    hasUrl: !!SUPABASE_URL,
    hasKey: !!SUPABASE_PUBLISHABLE_KEY,
    urlPrefix: SUPABASE_URL?.substring(0, 30),
    keyPrefix: SUPABASE_PUBLISHABLE_KEY?.substring(0, 20),
    availableEnvKeys: typeof process !== "undefined" ? Object.keys(process.env).filter((k) => k.includes("SUPABASE")) : "no-process"
  });
  if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) {
    const missing = [
      ...!SUPABASE_URL ? ["VITE_SUPABASE_URL"] : [],
      ...!SUPABASE_PUBLISHABLE_KEY ? ["VITE_SUPABASE_PUBLISHABLE_KEY or VITE_SUPABASE_ANON_KEY"] : []
    ];
    const message = `[Supabase] Missing env variables: ${missing.join(", ")}`;
    console.error(message);
    throw new Error(message);
  }
  return createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
    global: {
      fetch: createSupabaseFetch(SUPABASE_PUBLISHABLE_KEY)
    },
    auth: {
      storage: typeof window !== "undefined" ? localStorage : void 0,
      persistSession: true,
      autoRefreshToken: true
    }
  });
}
let _supabase;
const supabase = new Proxy({}, {
  get(_, prop, receiver) {
    try {
      if (!_supabase) _supabase = createSupabaseClient();
      return Reflect.get(_supabase, prop, receiver);
    } catch (error) {
      console.error("[Supabase] Failed to create client:", error);
      throw error;
    }
  }
});
export {
  supabase
};
