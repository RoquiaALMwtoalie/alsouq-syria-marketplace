import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { e as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { u as useQueryClient, b as useQuery, a as useMutation } from "../_libs/tanstack__react-query.mjs";
import { supabase } from "./client-B3mVC3Li.mjs";
import { Route$6, useApp, Button, cn, Badge, Avatar, AvatarImage, AvatarFallback, Textarea } from "./router-BExT9d3E.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { d as TriangleAlert, K as CircleX, a4 as ArrowRight, _ as CircleCheck, o as LoaderCircle, b as Clock, A as ArrowLeft, ap as FileText, V as Hash, N as Calendar, c4 as MessageSquare, U as User, q as Phone, a2 as MapPin, v as House, c as Store, P as Package, cp as UserCheck, cg as Wallet, a3 as Shield, $ as Send } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-dropdown-menu.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-menu.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-roving-focus.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-is-hydrated+[...].mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-tooltip.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/zustand.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/react-intersection-observer.mjs";
import "../_libs/radix-ui__react-tabs.mjs";
import "../_libs/radix-ui__react-radio-group.mjs";
import "../_libs/radix-ui__react-select.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-alert-dialog.mjs";
import "../_libs/radix-ui__react-checkbox.mjs";
import "../_libs/radix-ui__react-avatar.mjs";
import "../_libs/framer-motion.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
const STATUS_CONFIG = {
  open: {
    label_ar: "مفتوحة",
    label_en: "Open",
    color: "text-red-600 dark:text-red-400",
    bg: "bg-red-500/10",
    border: "border-red-500/30",
    icon: TriangleAlert,
    gradient: "from-red-500 to-rose-600"
  },
  pending: {
    label_ar: "قيد المراجعة",
    label_en: "Pending",
    color: "text-amber-600 dark:text-amber-400",
    bg: "bg-amber-500/10",
    border: "border-amber-500/30",
    icon: Clock,
    gradient: "from-amber-500 to-orange-600"
  },
  in_progress: {
    label_ar: "قيد المعالجة",
    label_en: "In Progress",
    color: "text-blue-600 dark:text-blue-400",
    bg: "bg-blue-500/10",
    border: "border-blue-500/30",
    icon: LoaderCircle,
    gradient: "from-blue-500 to-indigo-600"
  },
  resolved: {
    label_ar: "تم الحل",
    label_en: "Resolved",
    color: "text-emerald-600 dark:text-emerald-400",
    bg: "bg-emerald-500/10",
    border: "border-emerald-500/30",
    icon: CircleCheck,
    gradient: "from-emerald-500 to-teal-600"
  },
  closed: {
    label_ar: "مغلقة",
    label_en: "Closed",
    color: "text-slate-600 dark:text-slate-400",
    bg: "bg-slate-500/10",
    border: "border-slate-500/30",
    icon: CircleX,
    gradient: "from-slate-500 to-gray-600"
  },
  rejected: {
    label_ar: "مرفوضة",
    label_en: "Rejected",
    color: "text-rose-600 dark:text-rose-400",
    bg: "bg-rose-500/10",
    border: "border-rose-500/30",
    icon: CircleX,
    gradient: "from-rose-500 to-pink-600"
  }
};
function formatDate(date, isRTL, withTime = true) {
  if (!date) return "—";
  try {
    const options = {
      calendar: "gregory",
      year: "numeric",
      month: "long",
      day: "numeric"
    };
    if (withTime) {
      options.hour = "2-digit";
      options.minute = "2-digit";
    }
    return new Date(date).toLocaleDateString(isRTL ? "ar-SY" : "en-US", options);
  } catch {
    return "—";
  }
}
function formatPrice(price, currency, isRTL) {
  if (price === null || price === void 0) return "—";
  return `${Number(price).toLocaleString(isRTL ? "ar-SY" : "en-US")} ${currency || "SYP"}`;
}
function getInitials(name) {
  if (!name) return "?";
  return name.charAt(0).toUpperCase();
}
function ComplaintDetailPage() {
  const {
    id
  } = Route$6.useParams();
  const app = useApp();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const isRTL = app.lang === "ar";
  const [adminResponse, setAdminResponse] = reactExports.useState("");
  const [pendingStatus, setPendingStatus] = reactExports.useState("");
  const {
    data: complaint,
    isLoading,
    error
  } = useQuery({
    queryKey: ["complaint", id],
    enabled: !!id,
    queryFn: async () => {
      console.log("📡 [Complaint] Fetching:", id);
      const {
        data,
        error: error2
      } = await supabase.from("complaints").select(`
          *,
          customer:profiles!complaints_user_id_fkey (
            id,
            full_name,
            phone,
            avatar_url,
            city,
            address_text
          ),
          seller:profiles!complaints_seller_id_fkey (
            id,
            full_name,
            store_name,
            store_logo_url,
            store_phone,
            phone,
            store_address,
            avatar_url
          ),
          order:orders!complaints_order_id_fkey (
            id,
            total,
            currency,
            status,
            created_at,
            buyer_name,
            buyer_phone,
            delivery_address,
            quantity,
            order_items (
              id,
              quantity,
              price,
              currency,
              listing:listings (
                id,
                title_ar,
                title_en,
                cover_url,
                price,
                currency
              )
            )
          )
        `).eq("id", id).single();
      if (error2) {
        console.error("❌ [Complaint] Error:", error2);
        throw error2;
      }
      console.log("✅ [Complaint] Found:", data);
      return data;
    }
  });
  const updateComplaint = useMutation({
    mutationFn: async (params) => {
      const payload = {
        ...params,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      };
      if (params.status === "resolved" || params.status === "closed") {
        payload.resolved_at = (/* @__PURE__ */ new Date()).toISOString();
      }
      const {
        data,
        error: error2
      } = await supabase.from("complaints").update(payload).eq("id", id).select().single();
      if (error2) throw error2;
      return data;
    },
    onSuccess: () => {
      toast.success(isRTL ? "✅ تم تحديث الشكوى" : "✅ Complaint updated");
      queryClient.invalidateQueries({
        queryKey: ["complaint", id]
      });
      queryClient.invalidateQueries({
        queryKey: ["complaints"]
      });
      setAdminResponse("");
      setPendingStatus("");
    },
    onError: (err) => {
      toast.error(isRTL ? `❌ فشل: ${err.message}` : `❌ Failed: ${err.message}`);
    }
  });
  const handleStatusChange = async (status2) => {
    if (status2 === complaint?.status) return;
    setPendingStatus(status2);
    try {
      await updateComplaint.mutateAsync({
        status: status2
      });
    } catch {
      setPendingStatus("");
    }
  };
  const handleSubmitResponse = async () => {
    if (!adminResponse.trim()) {
      toast.error(isRTL ? "⚠️ اكتب الرد أولاً" : "⚠️ Write a response first");
      return;
    }
    await updateComplaint.mutateAsync({
      admin_response: adminResponse.trim(),
      status: pendingStatus || complaint?.status
    });
  };
  if (isLoading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen flex items-center justify-center bg-gradient-to-br from-white via-[#2a655f]/5 to-[#3a8a82]/5 dark:from-[#0f172a] dark:via-[#0f172a] dark:to-[#2a655f]/5", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-16 w-16 rounded-full border-4 border-[#2a655f]/20 border-t-[#2a655f] animate-spin" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "absolute inset-0 m-auto h-6 w-6 text-[#2a655f] animate-pulse" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-600 dark:text-slate-300 font-semibold", children: isRTL ? "⏳ جاري تحميل تفاصيل الشكوى..." : "⏳ Loading complaint details..." })
    ] }) });
  }
  if (error || !complaint) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen flex items-center justify-center bg-gradient-to-br from-white via-[#2a655f]/5 to-[#3a8a82]/5 dark:from-[#0f172a] dark:via-[#0f172a] dark:to-[#2a655f]/5 p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md w-full text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-20 w-20 rounded-full bg-red-500/10 flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "h-10 w-10 text-red-500" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-slate-900 dark:text-white mb-2", children: isRTL ? "❌ الشكوى غير موجودة" : "❌ Complaint not found" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400 mb-6", children: isRTL ? "ربما تم حذفها أو الرابط غير صحيح" : "It may have been deleted or the link is invalid" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: () => navigate({
        to: "/admin",
        search: {
          tab: "complaints"
        }
      }), className: "rounded-xl bg-gradient-to-r from-[#2a655f] to-[#3a8a82] text-white", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: cn("h-4 w-4", isRTL ? "ml-2" : "mr-2 rotate-180") }),
        isRTL ? "العودة للشكاوى" : "Back to complaints"
      ] })
    ] }) });
  }
  const status = complaint.status || "open";
  const statusConfig = STATUS_CONFIG[status] || STATUS_CONFIG.open;
  const StatusIcon = statusConfig.icon;
  const customer = complaint.customer;
  const seller = complaint.seller;
  const order = complaint.order;
  const orderItems = order?.order_items || [];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: cn("min-h-screen bg-gradient-to-br from-white via-[#2a655f]/5 to-[#3a8a82]/5 dark:from-[#0f172a] dark:via-[#0f172a] dark:to-[#2a655f]/5 pb-12", isRTL && "font-arabic"), dir: isRTL ? "rtl" : "ltr", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "sticky top-0 z-30 bg-white/95 dark:bg-[#0f172a]/95 backdrop-blur-xl border-b-2 border-[#2a655f]/30 shadow-lg", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-0.5 w-full bg-gradient-to-r from-transparent via-[#2a655f] to-[#3a8a82] animate-pulse" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl px-4 h-16 flex items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "icon", onClick: () => navigate({
            to: "/admin",
            search: {
              tab: "complaints"
            }
          }), className: "rounded-xl hover:bg-[#2a655f]/10 shrink-0", children: isRTL ? /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-5 w-5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-5 w-5" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-10 w-10 rounded-xl bg-gradient-to-br from-[#2a655f] to-[#3a8a82] flex items-center justify-center shadow-lg shadow-[#2a655f]/30 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-5 w-5 text-white" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-base sm:text-lg font-bold text-[#2a655f] dark:text-[#3a8a82] truncate", children: isRTL ? "تفاصيل الشكوى" : "Complaint Details" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 font-mono truncate", children: [
              "#",
              id.slice(0, 8)
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { className: cn("border-2 flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold shrink-0", statusConfig.bg, statusConfig.color, statusConfig.border), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(StatusIcon, { className: cn("h-3.5 w-3.5", status === "in_progress" && pendingStatus === "in_progress" && "animate-spin") }),
          isRTL ? statusConfig.label_ar : statusConfig.label_en
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl px-4 py-6 space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-[#1e293b] rounded-2xl border-2 border-[#2a655f]/30 p-6 shadow-xl relative overflow-hidden", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-0 right-0 w-40 h-40 bg-gradient-to-br from-[#2a655f]/10 to-transparent rounded-full blur-3xl" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-14 w-14 rounded-2xl bg-gradient-to-br from-[#2a655f] to-[#3a8a82] flex items-center justify-center shadow-lg shadow-[#2a655f]/30 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-7 w-7 text-white" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl sm:text-2xl font-bold text-slate-900 dark:text-white break-words", children: complaint.subject || (isRTL ? "بدون عنوان" : "No title") }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 mt-2 text-xs text-slate-500 dark:text-slate-400 flex-wrap", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Hash, { className: "h-3.5 w-3.5" }),
                  id.slice(0, 8)
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-1 w-1 rounded-full bg-slate-300" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-3.5 w-3.5" }),
                  formatDate(complaint.created_at, isRTL)
                ] }),
                complaint.resolved_at && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-1 w-1 rounded-full bg-slate-300" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1 text-emerald-600 dark:text-emerald-400", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-3.5 w-3.5" }),
                    isRTL ? "حُلّت: " : "Resolved: ",
                    formatDate(complaint.resolved_at, isRTL, false)
                  ] })
                ] })
              ] })
            ] })
          ] }),
          complaint.description && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border-2 border-slate-200 dark:border-slate-700", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "h-4 w-4 text-[#2a655f]" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-[#2a655f] dark:text-[#3a8a82] uppercase tracking-wider", children: isRTL ? "وصف الشكوى" : "Complaint Description" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap", children: complaint.description })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-[#1e293b] rounded-2xl border-2 border-[#2a655f]/30 p-6 shadow-xl relative overflow-hidden", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-blue-500/10 to-transparent rounded-full blur-3xl" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 rounded-lg bg-blue-500/10 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-4 w-4 text-blue-600" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider", children: isRTL ? "مقدم الشكوى" : "Complainant" })
            ] }),
            customer ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Avatar, { className: "h-16 w-16 rounded-2xl ring-2 ring-blue-500/30 shrink-0", children: customer.avatar_url ? /* @__PURE__ */ jsxRuntimeExports.jsx(AvatarImage, { src: customer.avatar_url, alt: customer.full_name, className: "object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(AvatarFallback, { className: "bg-gradient-to-br from-blue-500 to-indigo-600 text-white text-xl font-bold", children: getInitials(customer.full_name) }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0 space-y-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-base font-bold text-slate-900 dark:text-white truncate", children: customer.full_name || (isRTL ? "عميل" : "Customer") }),
                customer.phone && /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: `tel:${customer.phone}`, className: "flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400 hover:text-blue-600 transition-colors", dir: "ltr", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "h-3.5 w-3.5 text-blue-500" }),
                  customer.phone
                ] }),
                customer.city && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "h-3.5 w-3.5 text-blue-500" }),
                  customer.city
                ] }),
                customer.address_text && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "flex items-center gap-2 text-xs text-slate-500 dark:text-slate-500", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(House, { className: "h-3.5 w-3.5 text-blue-500 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: customer.address_text })
                ] })
              ] })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-6", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-10 w-10 mx-auto text-slate-300 dark:text-slate-600 mb-2" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-400 italic", children: isRTL ? "لا توجد بيانات للعميل" : "No customer data" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-[#1e293b] rounded-2xl border-2 border-[#2a655f]/30 p-6 shadow-xl relative overflow-hidden", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-amber-500/10 to-transparent rounded-full blur-3xl" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 rounded-lg bg-amber-500/10 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Store, { className: "h-4 w-4 text-amber-600" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider", children: isRTL ? "المتجر المشتكى عليه" : "Reported Store" })
            ] }),
            seller ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Avatar, { className: "h-16 w-16 rounded-2xl ring-2 ring-amber-500/30 shrink-0", children: seller.store_logo_url ? /* @__PURE__ */ jsxRuntimeExports.jsx(AvatarImage, { src: seller.store_logo_url, alt: seller.store_name, className: "object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(AvatarFallback, { className: "bg-gradient-to-br from-amber-500 to-orange-600 text-white text-xl font-bold", children: getInitials(seller.store_name || seller.full_name) }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0 space-y-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-base font-bold text-slate-900 dark:text-white truncate", children: seller.store_name || seller.full_name || (isRTL ? "متجر" : "Store") }),
                (seller.store_phone || seller.phone) && /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: `tel:${seller.store_phone || seller.phone}`, className: "flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400 hover:text-amber-600 transition-colors", dir: "ltr", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "h-3.5 w-3.5 text-amber-500" }),
                  seller.store_phone || seller.phone
                ] }),
                seller.store_address && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "h-3.5 w-3.5 text-amber-500 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: seller.store_address })
                ] })
              ] })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-6", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Store, { className: "h-10 w-10 mx-auto text-slate-300 dark:text-slate-600 mb-2" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-400 italic", children: isRTL ? "شكوى على المنصة (بدون بائع محدد)" : "Platform complaint (no specific seller)" })
            ] })
          ] })
        ] })
      ] }),
      order && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-[#1e293b] rounded-2xl border-2 border-[#2a655f]/30 p-6 shadow-xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 rounded-lg bg-[#2a655f]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Package, { className: "h-4 w-4 text-[#2a655f]" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold text-[#2a655f] dark:text-[#3a8a82] uppercase tracking-wider", children: isRTL ? "الطلب المرتبط" : "Related Order" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4 pb-4 border-b border-slate-200 dark:border-slate-700", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-slate-500 dark:text-slate-400 uppercase mb-1", children: isRTL ? "رقم الطلب" : "Order ID" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs font-mono font-bold text-slate-900 dark:text-white", children: [
              "#",
              order.id.slice(0, 8)
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-slate-500 dark:text-slate-400 uppercase mb-1", children: isRTL ? "الإجمالي" : "Total" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold text-[#2a655f] dark:text-[#3a8a82]", children: formatPrice(order.total, order.currency, isRTL) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-slate-500 dark:text-slate-400 uppercase mb-1", children: isRTL ? "الحالة" : "Status" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold text-slate-700 dark:text-slate-300", children: order.status })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-slate-500 dark:text-slate-400 uppercase mb-1", children: isRTL ? "التاريخ" : "Date" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-slate-700 dark:text-slate-300", children: formatDate(order.created_at, isRTL, false) })
          ] })
        ] }),
        (order.buyer_name || order.buyer_phone) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 p-3 rounded-xl bg-[#2a655f]/5 border border-[#2a655f]/20", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-[#2a655f] dark:text-[#3a8a82] font-bold uppercase mb-2", children: isRTL ? "بيانات المشتري في الطلب" : "Order Buyer Info" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4 text-xs", children: [
            order.buyer_name && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5 text-slate-700 dark:text-slate-300", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "h-3.5 w-3.5 text-[#2a655f]" }),
              order.buyer_name
            ] }),
            order.buyer_phone && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5 text-slate-700 dark:text-slate-300", dir: "ltr", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "h-3.5 w-3.5 text-[#2a655f]" }),
              order.buyer_phone
            ] })
          ] })
        ] }),
        orderItems.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold text-slate-600 dark:text-slate-400 mb-2", children: isRTL ? `المنتجات في الطلب (${orderItems.length})` : `Order Items (${orderItems.length})` }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: orderItems.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 hover:border-[#2a655f]/30 transition-colors", children: [
            item.listing?.cover_url ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: item.listing.cover_url, alt: item.listing.title_ar, className: "h-14 w-14 rounded-xl object-cover border-2 border-[#2a655f]/20 shrink-0" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-14 w-14 rounded-xl bg-slate-200 dark:bg-slate-700 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Package, { className: "h-6 w-6 text-slate-400" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-bold text-slate-900 dark:text-white truncate", children: isRTL ? item.listing?.title_ar : item.listing?.title_en || item.listing?.title_ar }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 mt-1 text-xs text-slate-500 dark:text-slate-400", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Hash, { className: "h-3 w-3" }),
                  isRTL ? "الكمية:" : "Qty:",
                  " ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-slate-700 dark:text-slate-300", children: item.quantity })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Wallet, { className: "h-3 w-3" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-[#2a655f] dark:text-[#3a8a82]", children: formatPrice(item.price, item.currency, isRTL) })
                ] })
              ] })
            ] })
          ] }, item.id)) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-[#1e293b] rounded-2xl border-2 border-[#2a655f]/30 p-6 shadow-xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 rounded-lg bg-emerald-500/10 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "h-4 w-4 text-emerald-600" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider", children: isRTL ? "الرد الإداري" : "Admin Response" })
        ] }),
        complaint.admin_response ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/20 border-2 border-emerald-200 dark:border-emerald-800/30", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-emerald-800 dark:text-emerald-200 leading-relaxed whitespace-pre-wrap", children: complaint.admin_response }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-emerald-600 dark:text-emerald-400 mt-3 flex items-center gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-3 w-3" }),
            formatDate(complaint.updated_at || complaint.resolved_at, isRTL)
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-8", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "h-10 w-10 mx-auto text-slate-300 dark:text-slate-600 mb-2" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-400", children: isRTL ? "لا يوجد رد إداري بعد" : "No admin response yet" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-400 mt-1", children: isRTL ? "اكتب الرد من الأسفل ⬇" : "Write a response below ⬇" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-[#1e293b] rounded-2xl border-2 border-[#2a655f]/30 p-6 shadow-xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-8 rounded-lg bg-[#2a655f]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "h-4 w-4 text-[#2a655f]" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold text-[#2a655f] dark:text-[#3a8a82] uppercase tracking-wider", children: isRTL ? "الإجراءات الإدارية" : "Admin Actions" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs font-bold text-slate-600 dark:text-slate-400 block mb-2", children: isRTL ? "تغيير حالة الشكوى:" : "Change Complaint Status:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2", children: Object.keys(STATUS_CONFIG).map((s) => {
            const cfg = STATUS_CONFIG[s];
            const Icon = cfg.icon;
            const isActive = status === s;
            const isPendingThis = pendingStatus === s;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => handleStatusChange(s), disabled: updateComplaint.isPending || isActive, className: cn("relative flex flex-col items-center gap-1.5 px-3 py-3 rounded-xl text-xs font-bold border-2 transition-all duration-300", isActive ? `${cfg.bg} ${cfg.color} ${cfg.border} scale-105 shadow-lg` : "bg-slate-50 dark:bg-slate-800/50 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-[#2a655f]/40 hover:scale-[1.02]", (updateComplaint.isPending || isActive) && "opacity-60 cursor-not-allowed"), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: cn("h-4 w-4", (s === "in_progress" || isPendingThis) && "animate-spin") }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center leading-tight", children: isRTL ? cfg.label_ar : cfg.label_en }),
              isActive && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-1 -right-1 h-3 w-3 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" })
            ] }, s);
          }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t-2 border-slate-200 dark:border-slate-700 pt-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs font-bold text-slate-600 dark:text-slate-400 block mb-2", children: isRTL ? "اكتب رداً إدارياً:" : "Write Admin Response:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: adminResponse, onChange: (e) => setAdminResponse(e.target.value), placeholder: isRTL ? "اكتب ردك على الشكوى هنا... سيظهر للعميل" : "Write your response here... It will be shown to the customer", rows: 5, className: "rounded-xl border-2 border-slate-200 dark:border-slate-700 focus:border-[#2a655f] focus:ring-2 focus:ring-[#2a655f]/20 resize-none text-sm" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3 mt-4 flex-wrap", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-400", children: isRTL ? "💡 الرد سيُحفظ مع الشكوى وسيراه العميل" : "💡 Response will be saved and visible to the customer" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", onClick: () => {
                setAdminResponse("");
                setPendingStatus("");
              }, disabled: updateComplaint.isPending, className: "rounded-xl", children: isRTL ? "إلغاء" : "Cancel" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: handleSubmitResponse, disabled: updateComplaint.isPending || !adminResponse.trim(), className: "rounded-xl bg-gradient-to-r from-[#2a655f] to-[#3a8a82] hover:from-[#1a4f4a] hover:to-[#2a655f] text-white shadow-lg shadow-[#2a655f]/30 hover:shadow-xl transition-all", children: [
                updateComplaint.isPending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: cn("h-4 w-4 animate-spin", isRTL ? "ml-2" : "mr-2") }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: cn("h-4 w-4", isRTL ? "ml-2" : "mr-2") }),
                isRTL ? "إرسال الرد" : "Send Response"
              ] })
            ] })
          ] })
        ] })
      ] })
    ] })
  ] });
}
export {
  ComplaintDetailPage as component
};
