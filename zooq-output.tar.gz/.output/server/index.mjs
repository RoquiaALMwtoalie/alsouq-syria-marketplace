globalThis.__nitro_main__ = import.meta.url;
import { c as NodeResponse, s as serve } from "./_libs/srvx.mjs";
import { d as defineHandler, H as HTTPError, t as toEventHandler, a as defineLazyEventHandler, h as headers, b as H3Core, m as memoizeRouteRulesMatcher, c as createMatcherFromFind, e as composeMiddleware } from "./_libs/h3.mjs";
import { H as HookableCore } from "./_libs/hookable.mjs";
import { d as decodePath, w as withLeadingSlash, a as withoutTrailingSlash, j as joinURL } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import "node:http";
import "node:stream";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "./_libs/rou3.mjs";
const assets = {
  "/manifest.json": {
    "type": "application/json",
    "etag": '"244-QA52B9OVrJ9YeraxYGuTTAb+GIY"',
    "mtime": "2026-09-13T08:09:35.885Z",
    "size": 580,
    "path": "../public/manifest.json"
  },
  "/banners/banner-electronics.jpg": {
    "type": "image/jpeg",
    "etag": '"1782b-xHAJLXtdjcvi4ownICzFvwzcqRU"',
    "mtime": "2026-07-19T07:11:02.000Z",
    "size": 96299,
    "path": "../public/banners/banner-electronics.jpg"
  },
  "/notification.mp3": {
    "type": "audio/mpeg",
    "etag": '"2cd0-Q9EijaBUU5U1+YwV6p7q7V50W/U"',
    "mtime": "2026-09-28T08:16:21.576Z",
    "size": 11472,
    "path": "../public/notification.mp3"
  },
  "/assets/activity-CNxxiqQk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"eb-wHnxcFAqsRsXkfPjR29QYHLLpGs"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 235,
    "path": "../public/assets/activity-CNxxiqQk.js"
  },
  "/assets/admin-DWNzj7UK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"461-+fq/F/ddbzfzW3ZVoxEupWrz0L4"',
    "mtime": "2026-10-17T11:36:49.427Z",
    "size": 1121,
    "path": "../public/assets/admin-DWNzj7UK.js"
  },
  "/assets/admin.complaints._id-CBYKyuOn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5abd-ZUqqyJXPovt+ggqnbm/7WkeWsSY"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 23229,
    "path": "../public/assets/admin.complaints._id-CBYKyuOn.js"
  },
  "/assets/ai-Drv8KdRa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1683-Fgu1LyZHHDS3wywhFDmWJo+tUNA"',
    "mtime": "2026-10-17T11:36:49.427Z",
    "size": 5763,
    "path": "../public/assets/ai-Drv8KdRa.js"
  },
  "/assets/Area-Bm1nFXLB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2a18-TvlKfSWL+18Sc24nIYrQMbpsGZk"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 10776,
    "path": "../public/assets/Area-Bm1nFXLB.js"
  },
  "/assets/auth._mode-DMPTMMK7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a067-jcreDZmFCLGaXegUY9RH6i31c+A"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 41063,
    "path": "../public/assets/auth._mode-DMPTMMK7.js"
  },
  "/assets/badge-check-C5n0nkVF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"138-IuoRcqXVC2T7iV3Tk0d6h9fx2gw"',
    "mtime": "2026-10-17T11:36:49.431Z",
    "size": 312,
    "path": "../public/assets/badge-check-C5n0nkVF.js"
  },
  "/assets/cairo-arabic-wght-normal-CJWMIGCx.woff2": {
    "type": "font/woff2",
    "etag": '"78b0-cU1AzwfbFfqSaOpgchHDFDjk3tQ"',
    "mtime": "2026-10-17T11:36:49.427Z",
    "size": 30896,
    "path": "../public/assets/cairo-arabic-wght-normal-CJWMIGCx.woff2"
  },
  "/assets/cairo-latin-ext-wght-normal-at8nfxId.woff2": {
    "type": "font/woff2",
    "etag": '"4108-zOtqczmdcVU5SEtzywLHCnpUjXU"',
    "mtime": "2026-10-17T11:36:49.426Z",
    "size": 16648,
    "path": "../public/assets/cairo-latin-ext-wght-normal-at8nfxId.woff2"
  },
  "/banners/banner-fashion.jpg": {
    "type": "image/jpeg",
    "etag": '"28421-R5M0K734HbOSu1fx8Aqd8Mco5J0"',
    "mtime": "2026-07-19T07:11:02.000Z",
    "size": 164897,
    "path": "../public/banners/banner-fashion.jpg"
  },
  "/banners/banner-offers.jpg": {
    "type": "image/jpeg",
    "etag": '"1bf83-sM2jF7ALBpKHHZo6QMYUC2XK4V4"',
    "mtime": "2026-07-19T07:11:02.000Z",
    "size": 114563,
    "path": "../public/banners/banner-offers.jpg"
  },
  "/assets/cairo-latin-wght-normal-PfPtmrPZ.woff2": {
    "type": "font/woff2",
    "etag": '"841c-yqL1cry74phalqnVmkWbLRmQs1Y"',
    "mtime": "2026-10-17T11:36:49.426Z",
    "size": 33820,
    "path": "../public/assets/cairo-latin-wght-normal-PfPtmrPZ.woff2"
  },
  "/assets/card-BCodxcX2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3d4-230OreuawEi1ipX6z2KzWIqG0As"',
    "mtime": "2026-10-17T11:36:49.431Z",
    "size": 980,
    "path": "../public/assets/card-BCodxcX2.js"
  },
  "/assets/chart-column-D5ksELYI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"fc-bFFPshqb1LW9S4KbZ/L7edkqPm4"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 252,
    "path": "../public/assets/chart-column-D5ksELYI.js"
  },
  "/assets/BarChart-zG_2V03r.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5df38-d9O3ompfVRbgkO5WxDPS1vKxoPc"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 384824,
    "path": "../public/assets/BarChart-zG_2V03r.js"
  },
  "/assets/ChatMessages-CRy55IpV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"128f0-8JI116UFuPDSctoAGh5O9I65e8M"',
    "mtime": "2026-10-17T11:36:49.431Z",
    "size": 76016,
    "path": "../public/assets/ChatMessages-CRy55IpV.js"
  },
  "/assets/check-check-DS71AK5J.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"af-BpXlKrSfKh1UoxkNKYOBpz1xXW8"',
    "mtime": "2026-10-17T11:36:49.431Z",
    "size": 175,
    "path": "../public/assets/check-check-DS71AK5J.js"
  },
  "/assets/coins-D7wHZpA8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"119-hAjfbTBmAd8jx/apq4VJu9SYWo0"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 281,
    "path": "../public/assets/coins-D7wHZpA8.js"
  },
  "/assets/compass-BugMxs7h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"f7-Ppqllr4/uaosVwbLYN0QU4vRfFo"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 247,
    "path": "../public/assets/compass-BugMxs7h.js"
  },
  "/assets/complete-DhbsXNn4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"45ea-fSAZWidcQHAYDq+rNxX15tp8Lfg"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 17898,
    "path": "../public/assets/complete-DhbsXNn4.js"
  },
  "/sw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1496-joJAzB0IAyyWsHIJ78tmSglb8OY"',
    "mtime": "2026-09-13T17:39:25.621Z",
    "size": 5270,
    "path": "../public/sw.js"
  },
  "/assets/AdminDashboard-CEdK9juN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"dbcf6-RnYmBh39LrRRc1AD/fCNSy28jS8"',
    "mtime": "2026-10-17T11:36:49.435Z",
    "size": 900342,
    "path": "../public/assets/AdminDashboard-CEdK9juN.js"
  },
  "/assets/conversation._userId-CMWSGRFp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1a8c-/Q6cxja9GwvBvG93a9G0bAYoT6s"',
    "mtime": "2026-10-17T11:36:49.431Z",
    "size": 6796,
    "path": "../public/assets/conversation._userId-CMWSGRFp.js"
  },
  "/assets/conversation._userId-jKzffftz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1a89-yblVs/H3Dhg9zbLw5F9dZUeRl5I"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 6793,
    "path": "../public/assets/conversation._userId-jKzffftz.js"
  },
  "/assets/dashboard-BFdOFeMN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1d4dd-VzVEvg0xMcLXXiuUMbJ4d3tzxdA"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 120029,
    "path": "../public/assets/dashboard-BFdOFeMN.js"
  },
  "/assets/dashboard-B9ATH04G.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2d7e5-3uBqICf6DTl+moXXXUreGCxmqWI"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 186341,
    "path": "../public/assets/dashboard-B9ATH04G.js"
  },
  "/assets/distributors-CBG35NDR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"c912-64ciDTgMW9eb5VVMI++/VUogqhM"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 51474,
    "path": "../public/assets/distributors-CBG35NDR.js"
  },
  "/assets/dollar-sign-Bc056Eml.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"dc-nKstSTNQ+AatNcM0fbnGKLefOQo"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 220,
    "path": "../public/assets/dollar-sign-Bc056Eml.js"
  },
  "/assets/download-C9j9CIrw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"e9-OLivLvj5f+Z6HErgLLe+o1F8RFg"',
    "mtime": "2026-10-17T11:36:49.431Z",
    "size": 233,
    "path": "../public/assets/download-C9j9CIrw.js"
  },
  "/assets/dashboard-HL5a2CDs.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6cd54-C+7ATRm2nbECd9Wg9xqVtC7ZZvQ"',
    "mtime": "2026-10-17T11:36:49.427Z",
    "size": 445780,
    "path": "../public/assets/dashboard-HL5a2CDs.js"
  },
  "/assets/eye-off-DhfJQZWC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1af-fjVX0gxGokOvuat7ONSqKUIzOv0"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 431,
    "path": "../public/assets/eye-off-DhfJQZWC.js"
  },
  "/assets/faq-HV9Td0Bg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"23d2-ncdk/YkAe1MIXE5Jgng0s5BFjjc"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 9170,
    "path": "../public/assets/faq-HV9Td0Bg.js"
  },
  "/assets/file-spreadsheet-DOixcI6m.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1ad-0PCwmYJ89q64cBtaKXVkTD0Oaxs"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 429,
    "path": "../public/assets/file-spreadsheet-DOixcI6m.js"
  },
  "/assets/favorites-BgMjVCco.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"59ed-Ag3dl7VRCEIz+8DZm7m0DdtOUsQ"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 23021,
    "path": "../public/assets/favorites-BgMjVCco.js"
  },
  "/assets/index-AgfFnXkr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"14b7-KxvWjcaXUNY9jMtwgV/7NeF2/LQ"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 5303,
    "path": "../public/assets/index-AgfFnXkr.js"
  },
  "/assets/index-BvQ2bIUq.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"a5d-xURFBBVe6o5qWAyyD4vDaDs0fxo"',
    "mtime": "2026-10-17T11:36:49.427Z",
    "size": 2653,
    "path": "../public/assets/index-BvQ2bIUq.css"
  },
  "/assets/index-CfTBUlNF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"74e6-qSl1Lat101Cd38Zz8GZlzDZZ5Hw"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 29926,
    "path": "../public/assets/index-CfTBUlNF.js"
  },
  "/assets/languages-CpTspVMl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"270-jkC/roqk6qzxRNc8a4e8Thwq31c"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 624,
    "path": "../public/assets/languages-CpTspVMl.js"
  },
  "/assets/LeafletMap-CIGW-MKW.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"3cf7-GSfYBurqLbmcVM5PnUOstAgC2rk"',
    "mtime": "2026-10-17T11:36:49.427Z",
    "size": 15607,
    "path": "../public/assets/LeafletMap-CIGW-MKW.css"
  },
  "/assets/LeafletMap-CJHAxpgC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"27070-sVkHU53EvGkVAcY7Oj1RccRKM0Q"',
    "mtime": "2026-10-17T11:36:49.432Z",
    "size": 159856,
    "path": "../public/assets/LeafletMap-CJHAxpgC.js"
  },
  "/assets/lock-CGdMlD_Q.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ca-R8FKcCc17OEjV4kLDf8an2PN3G4"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 202,
    "path": "../public/assets/lock-CGdMlD_Q.js"
  },
  "/assets/map-DJrJNNDA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1aa-55cYespcwL638mY9Bf3MmzAmOlg"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 426,
    "path": "../public/assets/map-DJrJNNDA.js"
  },
  "/assets/map-pinned-CPMlrtge.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"190-xpyyIDz+iRuCK8oAUKdpIeZR/H4"',
    "mtime": "2026-10-17T11:36:49.431Z",
    "size": 400,
    "path": "../public/assets/map-pinned-CPMlrtge.js"
  },
  "/assets/message-square-DhINlokt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ea-Ap3qW9+iPV8b5SnkhdoI0OCPMYE"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 234,
    "path": "../public/assets/message-square-DhINlokt.js"
  },
  "/assets/messages-BqP8aODo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"72c8-2m+FRbGbJa0JU7V7mt6HF8khhZ8"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 29384,
    "path": "../public/assets/messages-BqP8aODo.js"
  },
  "/assets/messages-k265YutS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2334-Dyr+Swg3D0FXMR8mBpgO6MevELs"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 9012,
    "path": "../public/assets/messages-k265YutS.js"
  },
  "/assets/index-Ce_eSJ_s.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1ab161-65QUT8Xf1UhiDn7IqbeA8ikh+zk"',
    "mtime": "2026-10-17T11:36:49.444Z",
    "size": 1749345,
    "path": "../public/assets/index-Ce_eSJ_s.js"
  },
  "/assets/messages_._userId-CP73tBCt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1503-DLDuDHbVqurbrOR9KTeukAns0lk"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 5379,
    "path": "../public/assets/messages_._userId-CP73tBCt.js"
  },
  "/assets/mock-data-hAt1jloX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1386-HcOxeJbem8j3yUyIbXSOdON7Bko"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 4998,
    "path": "../public/assets/mock-data-hAt1jloX.js"
  },
  "/assets/new-C0A9qD0q.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4451-GGDFw94tGjO4oBD1cIvUn7l1ZRI"',
    "mtime": "2026-10-17T11:36:49.431Z",
    "size": 17489,
    "path": "../public/assets/new-C0A9qD0q.js"
  },
  "/assets/pen-line-BzCkrRb0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"116-f5WV6npVt8R92rqC8VPclN3hjbs"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 278,
    "path": "../public/assets/pen-line-BzCkrRb0.js"
  },
  "/assets/PieChart-CVG_e6n2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"8fbc-30fiANO9+Dt6ci/p7Ti7fGXYbAI"',
    "mtime": "2026-10-17T11:36:49.427Z",
    "size": 36796,
    "path": "../public/assets/PieChart-CVG_e6n2.js"
  },
  "/assets/popover-QTuRQbQZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"13ae-gtjP7+PEVGxozjzS0yqmwJeSFII"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 5038,
    "path": "../public/assets/popover-QTuRQbQZ.js"
  },
  "/assets/power-Cj9Jcoug.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"195-Bv3UmQz3t0cMHj0MYtfd16x5Tlg"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 405,
    "path": "../public/assets/power-Cj9Jcoug.js"
  },
  "/assets/privacy-BRjxIbIS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"31e9-LwOjA+XR97h6hdZvmiOY/347D+c"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 12777,
    "path": "../public/assets/privacy-BRjxIbIS.js"
  },
  "/assets/profile-VPWKZDW2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"15ab-LulRAJCEz4tNZi9XEI2Ku5WS9uw"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 5547,
    "path": "../public/assets/profile-VPWKZDW2.js"
  },
  "/assets/reports-COvOETQ9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"138a-mpfNpvk/y9E/a3j/wptEhskSlEs"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 5002,
    "path": "../public/assets/reports-COvOETQ9.js"
  },
  "/assets/reports-Datlw2Ab.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5051-4r//S7HUexeKGXmFXEVqpMcJ6KY"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 20561,
    "path": "../public/assets/reports-Datlw2Ab.js"
  },
  "/assets/reset-password-D5BTzReP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1256-h5HLweEwxzJsjF+LGh6MTR+N81A"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 4694,
    "path": "../public/assets/reset-password-D5BTzReP.js"
  },
  "/assets/save-BM5aFppY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"148-R3srP8TbiU6Jl651F61ykz1ijFs"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 328,
    "path": "../public/assets/save-BM5aFppY.js"
  },
  "/assets/settings-CCjQthZ0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"939a-qeB4DNayDFErVByYtZ6AH9fCi5g"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 37786,
    "path": "../public/assets/settings-CCjQthZ0.js"
  },
  "/assets/search-BzZLpcYN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"e876-n957owfYtWp3bd24vUayqF/ucSI"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 59510,
    "path": "../public/assets/search-BzZLpcYN.js"
  },
  "/assets/space-grotesk-latin-400-normal-BnQMeOim.woff": {
    "type": "font/woff",
    "etag": '"426c-ghmNOmJRvnMHZL5v05+7tCgOuLs"',
    "mtime": "2026-10-17T11:36:49.426Z",
    "size": 17004,
    "path": "../public/assets/space-grotesk-latin-400-normal-BnQMeOim.woff"
  },
  "/assets/settings-D-mWGPqi.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4394-kfTcelP35dDBZmAZwrFmXl/4Mf0"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 17300,
    "path": "../public/assets/settings-D-mWGPqi.js"
  },
  "/assets/space-grotesk-latin-400-normal-CJ-V5oYT.woff2": {
    "type": "font/woff2",
    "etag": '"344c-4RfT7aFk3EnbF6Hh/aQS0Dwt6dI"',
    "mtime": "2026-10-17T11:36:49.426Z",
    "size": 13388,
    "path": "../public/assets/space-grotesk-latin-400-normal-CJ-V5oYT.woff2"
  },
  "/assets/space-grotesk-latin-700-normal-CwsQ-cCU.woff": {
    "type": "font/woff",
    "etag": '"4020-6+Lv6SyfClI9gHZHIfMCmlje8BE"',
    "mtime": "2026-10-17T11:36:49.427Z",
    "size": 16416,
    "path": "../public/assets/space-grotesk-latin-700-normal-CwsQ-cCU.woff"
  },
  "/assets/square-pen-Db4xdSwO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"141-HArgDmvR433AqaWJMZiK2ku+qMA"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 321,
    "path": "../public/assets/square-pen-Db4xdSwO.js"
  },
  "/assets/store._id-CYyassFU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"9ea2-dFIFkOUEky7oRpJcvX8yB3xGrz8"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 40610,
    "path": "../public/assets/store._id-CYyassFU.js"
  },
  "/assets/space-grotesk-latin-700-normal-RjhwGPKo.woff2": {
    "type": "font/woff2",
    "etag": '"3228-CUaBya012LbSd7QFPXYy34srV9k"',
    "mtime": "2026-10-17T11:36:49.426Z",
    "size": 12840,
    "path": "../public/assets/space-grotesk-latin-700-normal-RjhwGPKo.woff2"
  },
  "/assets/styles-BVT1A_vm.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"68f15-a6sgMQd96begstjT3T7eIyLWsV4"',
    "mtime": "2026-10-17T11:36:49.427Z",
    "size": 429845,
    "path": "../public/assets/styles-BVT1A_vm.css"
  },
  "/assets/switch-CaGTMarV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1049-qsZAlCKk5IqnTWAElFhrJxxiwdU"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 4169,
    "path": "../public/assets/switch-CaGTMarV.js"
  },
  "/assets/table-CKCxXzJl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"61a-UyXyQ025AfVlA6+Tn103URzK5Gw"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 1562,
    "path": "../public/assets/table-CKCxXzJl.js"
  },
  "/assets/tajawal-arabic-400-normal-CyCXRvzh.woff2": {
    "type": "font/woff2",
    "etag": '"22e4-htzAFQstcbuMF+wRaCzQur6CVr4"',
    "mtime": "2026-10-17T11:36:49.378Z",
    "size": 8932,
    "path": "../public/assets/tajawal-arabic-400-normal-CyCXRvzh.woff2"
  },
  "/assets/tajawal-arabic-400-normal-DCQxawbB.woff": {
    "type": "font/woff",
    "etag": '"2eec-vFoXwU3KrmLj8pnTxB6gXpwdzXs"',
    "mtime": "2026-10-17T11:36:49.426Z",
    "size": 12012,
    "path": "../public/assets/tajawal-arabic-400-normal-DCQxawbB.woff"
  },
  "/assets/tajawal-arabic-700-normal-9L7Zusdl.woff": {
    "type": "font/woff",
    "etag": '"2f80-4RWf3CKpG924VXeRmL/sd+C9M1M"',
    "mtime": "2026-10-17T11:36:49.426Z",
    "size": 12160,
    "path": "../public/assets/tajawal-arabic-700-normal-9L7Zusdl.woff"
  },
  "/assets/tajawal-arabic-700-normal-D2-eand5.woff2": {
    "type": "font/woff2",
    "etag": '"2340-GPygwY9uCPibTwXPwIY4Le7OnYg"',
    "mtime": "2026-10-17T11:36:49.426Z",
    "size": 9024,
    "path": "../public/assets/tajawal-arabic-700-normal-D2-eand5.woff2"
  },
  "/assets/tajawal-arabic-900-normal-MgmkhdPX.woff2": {
    "type": "font/woff2",
    "etag": '"21fc-u9LGlvQFzr5unanNdZ+90AppPIw"',
    "mtime": "2026-10-17T11:36:49.426Z",
    "size": 8700,
    "path": "../public/assets/tajawal-arabic-900-normal-MgmkhdPX.woff2"
  },
  "/assets/tajawal-arabic-900-normal-CHO_pm7-.woff": {
    "type": "font/woff",
    "etag": '"2e40-7qutE+85kzDH9ISHfuxrsjaLtto"',
    "mtime": "2026-10-17T11:36:49.426Z",
    "size": 11840,
    "path": "../public/assets/tajawal-arabic-900-normal-CHO_pm7-.woff"
  },
  "/assets/target-CZZu4ZIF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"de-JXAmBlKhVMF1yfTq/VxUnZapl3w"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 222,
    "path": "../public/assets/target-CZZu4ZIF.js"
  },
  "/assets/terms-DkhRwuwG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2610-Q1SSu92R4CD/r/iZrlos9h6oE7I"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 9744,
    "path": "../public/assets/terms-DkhRwuwG.js"
  },
  "/assets/timer-CI9WcUK6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ef-16sp2mXm6YPl6NfkJNN7o+bSYIo"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 239,
    "path": "../public/assets/timer-CI9WcUK6.js"
  },
  "/assets/user-check-CBb_YALC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ef-T2VTiAMfPr/k4YX6VEljxrOjY+Y"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 239,
    "path": "../public/assets/user-check-CBb_YALC.js"
  },
  "/assets/user-round-plus-CNBQIV3t.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"22f-xHEJK0FMlDxO9TEv8puxAmGaz6k"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 559,
    "path": "../public/assets/user-round-plus-CNBQIV3t.js"
  },
  "/assets/user-x-7aPIVu3u.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"133-nWfHVcIi7/nBP6TmT56pJq0A0N4"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 307,
    "path": "../public/assets/user-x-7aPIVu3u.js"
  },
  "/assets/users-round-KMg-x0ua.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"f9-iomIyApEL826nuQGF8Xw4ZeYtCE"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 249,
    "path": "../public/assets/users-round-KMg-x0ua.js"
  },
  "/assets/wallet-BXoTQ6_N.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"11f-U981rBBuFFoCEXmB4xabuBT93gM"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 287,
    "path": "../public/assets/wallet-BXoTQ6_N.js"
  },
  "/assets/_id-C1eNaVAY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3b49-U5xHzorrvxPRhjqPAlQVknumQwI"',
    "mtime": "2026-10-17T11:36:49.429Z",
    "size": 15177,
    "path": "../public/assets/_id-C1eNaVAY.js"
  },
  "/assets/_orderId-D51gF7C7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"30dd-sMFH7YA96BtUwmyoiQnF+fALcV8"',
    "mtime": "2026-10-17T11:36:49.431Z",
    "size": 12509,
    "path": "../public/assets/_orderId-D51gF7C7.js"
  },
  "/assets/_id-DrVpntks.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4540-Og7AWAGNEhsS2jg70nsu9wIJqH4"',
    "mtime": "2026-10-17T11:36:49.431Z",
    "size": 17728,
    "path": "../public/assets/_id-DrVpntks.js"
  },
  "/assets/_slug-C0RiycW1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"36db-1i88ipp6zB55k0e9382YFm6p8s0"',
    "mtime": "2026-10-17T11:36:49.428Z",
    "size": 14043,
    "path": "../public/assets/_slug-C0RiycW1.js"
  },
  "/assets/_trackingNumber-D-s5EC1O.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"30f5-7HyHhArgt66w+UK54nnOU9rozTQ"',
    "mtime": "2026-10-17T11:36:49.430Z",
    "size": 12533,
    "path": "../public/assets/_trackingNumber-D-s5EC1O.js"
  },
  "/images/download.jfif": {
    "type": "image/pjpeg",
    "etag": '"196c-tDuMLHaUfJNy1yg3qfzny+NqVEM"',
    "mtime": "2026-08-31T14:52:34.191Z",
    "size": 6508,
    "path": "../public/images/download.jfif"
  },
  "/images/delivery-man.png": {
    "type": "image/png",
    "etag": '"1d871-/iw6l6jYFn8clrNd00t+5DjCsFw"',
    "mtime": "2026-08-14T12:20:01.250Z",
    "size": 120945,
    "path": "../public/images/delivery-man.png"
  },
  "/images/Logo-transparent.png": {
    "type": "image/png",
    "etag": '"3b348-1ZHVNdG+6R8wG4DAV9jIJ1asbUc"',
    "mtime": "2026-09-03T07:09:05.003Z",
    "size": 242504,
    "path": "../public/images/Logo-transparent.png"
  },
  "/images/Logo.png": {
    "type": "image/png",
    "etag": '"3f8a6-46+Boc3GINzs/GcaPNaX6qXYgpY"',
    "mtime": "2026-09-02T14:28:18.558Z",
    "size": 260262,
    "path": "../public/images/Logo.png"
  }
};
function readAsset(id) {
  const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
  return promises.readFile(resolve(serverDir, assets[id].path));
}
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
function getAsset(id) {
  return assets[id];
}
const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = {
  gzip: ".gz",
  br: ".br",
  zstd: ".zst"
};
const _77d10cb957337f81 = defineHandler((event) => {
  if (event.req.method && !METHODS.has(event.req.method)) {
    return;
  }
  let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
  let asset;
  const encodingHeader = event.req.headers.get("accept-encoding") || "";
  const encodings = [...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.res.headers.delete("Cache-Control");
      throw new HTTPError({ status: 404 });
    }
    return;
  }
  if (encodings.length > 1) {
    event.res.headers.append("Vary", "Accept-Encoding");
  }
  const ifNotMatch = event.req.headers.get("if-none-match") === asset.etag;
  if (ifNotMatch) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  const ifModifiedSinceH = event.req.headers.get("if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  if (asset.type) {
    event.res.headers.set("Content-Type", asset.type);
  }
  if (asset.etag && !event.res.headers.has("ETag")) {
    event.res.headers.set("ETag", asset.etag);
  }
  if (asset.mtime && !event.res.headers.has("Last-Modified")) {
    event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.res.headers.has("Content-Encoding")) {
    event.res.headers.set("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.res.headers.has("Content-Length")) {
    event.res.headers.set("Content-Length", asset.size.toString());
  }
  return readAsset(id);
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = { route: "/assets/**", rank: 0, rules: [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }] };
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1);
    let s = p.split("/");
    let l = s.length;
    let _w;
    if (l > 1) {
      if (s[1] === "assets") {
        r.push(l > 2 ? { data: $0, params: { "0": _w = p.slice(8), _: _w } } : { data: $0, params: {} });
      }
    }
    return r.reverse();
  };
})();
const _lazy_c785bdf60a96e066 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_c785bdf60a96e066 };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const globalMiddleware = [
  toEventHandler(_77d10cb957337f81)
].filter(Boolean);
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
function createNitroApp() {
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({ error, context: errorCtx });
      }
    }
  };
  const h3App = createH3App({
    onError(error, event) {
      return errorHandler(error, event);
    }
  });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  return {
    fetch: appHandler,
    h3: h3App,
    hooks: void 0,
    captureError
  };
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => {
    event.context.routeRules = getRouteRules(event.req.method, event.url.pathname).routeRules;
    return findRoute(event.req.method, event.url.pathname);
  };
  h3App["~middleware"].push(createRouteRulesMiddleware());
  h3App["~middleware"].push(...globalMiddleware);
  return h3App;
}
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function useNitroHooks() {
  const nitroApp2 = useNitroApp();
  const hooks = nitroApp2.hooks;
  if (hooks) {
    return hooks;
  }
  return nitroApp2.hooks = new HookableCore();
}
let _matchRouteRules;
function getRouteRules(method, pathname) {
  return (_matchRouteRules ??= memoizeRouteRulesMatcher(createMatcherFromFind(findRouteRules)))(method, pathname);
}
function createRouteRulesMiddleware() {
  const composed = /* @__PURE__ */ new WeakMap();
  const middleware = (event, next) => {
    const ruleMiddleware = getRouteRules(event.req.method, event.url.pathname).routeRuleMiddleware;
    if (ruleMiddleware.length === 0) {
      return next();
    }
    let chain = composed.get(ruleMiddleware);
    if (!chain) {
      chain = composeMiddleware(ruleMiddleware);
      composed.set(ruleMiddleware, chain);
    }
    return chain(event, next);
  };
  return markUntraced(middleware);
}
function markUntraced(middleware) {
  middleware.__traced__ = true;
  return middleware;
}
function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
  process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
  process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
const tracingSrvxPlugins = [];
function setupCloseHooks(server2) {
  const closeServer = server2.close.bind(server2);
  let closeHooks;
  server2.close = (closeActiveConnections) => closeServer(closeActiveConnections).finally(() => closeHooks ??= callCloseHooks());
}
async function callCloseHooks() {
  try {
    await useNitroHooks().callHook("close");
  } catch (error) {
    console.error("[nitro] Error while calling `close` hooks:", error);
  }
}
const _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
const port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
const host = process.env.NITRO_HOST || process.env.HOST;
const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
const server = serve({
  port,
  hostname: host,
  tls: cert && key ? {
    cert,
    key
  } : void 0,
  fetch: nitroApp.fetch,
  plugins: [...tracingSrvxPlugins]
});
setupCloseHooks(server);
trapUnhandledErrors();
const nodeServer = {};
export {
  nodeServer as default
};
