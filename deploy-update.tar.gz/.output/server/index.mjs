globalThis.__nitro_main__ = import.meta.url;
import { b as NodeResponse, s as serve } from "./_libs/srvx.mjs";
import { d as defineHandler, H as HTTPError, t as toEventHandler, a as defineLazyEventHandler, b as H3Core } from "./_libs/h3.mjs";
import { d as decodePath, w as withLeadingSlash, a as withoutTrailingSlash, j as joinURL } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import "node:http";
import "node:stream";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "./_libs/rou3.mjs";
function lazyService(loader) {
  let promise, mod;
  return {
    fetch(req) {
      if (mod) {
        return mod.fetch(req);
      }
      if (!promise) {
        promise = loader().then((_mod) => mod = _mod.default || _mod);
      }
      return promise.then((mod2) => mod2.fetch(req));
    }
  };
}
const services = {
  ["ssr"]: lazyService(() => import("./_ssr/index.mjs"))
};
globalThis.__nitro_vite_envs__ = services;
const headers = ((m) => function headersRouteRule(event) {
  for (const [key2, value] of Object.entries(m.options || {})) {
    event.res.headers.set(key2, value);
  }
});
const assets = {
  "/assets/activity-qsGuqze7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"eb-20A/DQp4bpLH1lGioBAd2+crus0"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 235,
    "path": "../public/assets/activity-qsGuqze7.js"
  },
  "/assets/admin-D1j7kE0g.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3ca-+OQ3p9qwSyfVcxmyH3Ai3GZopZ0"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 970,
    "path": "../public/assets/admin-D1j7kE0g.js"
  },
  "/assets/ai-BghqCQzZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1683-vshVRXQA3pchiQvxyghHkjjKwjQ"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 5763,
    "path": "../public/assets/ai-BghqCQzZ.js"
  },
  "/assets/Area-Dp6T_DeV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2a18-knpx7+jzthQOtzuhtmXHLgWNh0g"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 10776,
    "path": "../public/assets/Area-Dp6T_DeV.js"
  },
  "/assets/auth._mode-C9uQa8_a.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a067-7ToDVYLWx1XfjuC6ekXCyPxDATo"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 41063,
    "path": "../public/assets/auth._mode-C9uQa8_a.js"
  },
  "/assets/badge-check-v3-i4eqb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"138-3PIyaYtzMjLlWgRv6Z+kzYFqiLE"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 312,
    "path": "../public/assets/badge-check-v3-i4eqb.js"
  },
  "/assets/card-Bfb_91bi.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3d4-HvFbeBeSrVJE7eu/B3vihVJXBU8"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 980,
    "path": "../public/assets/card-Bfb_91bi.js"
  },
  "/assets/chart-column-DA7GzUF-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"fc-dLuRQ1TJ5DzLEYRLFvOSl91MVo4"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 252,
    "path": "../public/assets/chart-column-DA7GzUF-.js"
  },
  "/assets/ChatMessages-BO2mg53X.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"128ca-8P4jI8KcqSfBMSJe1vU6CiMQXbg"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 75978,
    "path": "../public/assets/ChatMessages-BO2mg53X.js"
  },
  "/assets/check-check-W_IbDmFS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"af-iTKD+p39crL3goU/aTw8wQG0k2Q"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 175,
    "path": "../public/assets/check-check-W_IbDmFS.js"
  },
  "/assets/compass-DJv-sZRw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"f7-GtEvcKBTg0xzzOHVapRPJgdRQKM"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 247,
    "path": "../public/assets/compass-DJv-sZRw.js"
  },
  "/assets/complete-BEA80DVc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"45ea-oxdgCAyWZh2qDcFFt/A6AXUCv4o"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 17898,
    "path": "../public/assets/complete-BEA80DVc.js"
  },
  "/assets/BarChart-QbguXPcA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5df38-9XHw/S8TaJApFZv5kaZanPVaqTI"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 384824,
    "path": "../public/assets/BarChart-QbguXPcA.js"
  },
  "/assets/conversation._userId-Dgd6yzol.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"18c8-ro/Jt3TJOAW7+BSdd1dPEc+cUjg"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 6344,
    "path": "../public/assets/conversation._userId-Dgd6yzol.js"
  },
  "/assets/conversation._userId-OBgrzpWL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"18cb-PSMTsoTVFE0oq5iWNSQHd3VGKoo"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 6347,
    "path": "../public/assets/conversation._userId-OBgrzpWL.js"
  },
  "/assets/dashboard-BpVeZdSo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2bd37-P1HJ5CPEVDMt/ty+QLlIFTw6XCE"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 179511,
    "path": "../public/assets/dashboard-BpVeZdSo.js"
  },
  "/assets/dashboard-BFdoal8X.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1d4b6-UAC3PYpJWGOepOq+4ycKPSwPNMo"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 119990,
    "path": "../public/assets/dashboard-BFdoal8X.js"
  },
  "/assets/distributors-B_CPJJ_5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"addc-OnCKtyiCBm1OYpPZ5WrA1GTkbkY"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 44508,
    "path": "../public/assets/distributors-B_CPJJ_5.js"
  },
  "/assets/download-nlHxZ5nn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"e9-+geaCsKs7+T8xh4DdXi1B97GcvM"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 233,
    "path": "../public/assets/download-nlHxZ5nn.js"
  },
  "/assets/dollar-sign-ColLKL6U.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"dc-nE7frvgRySquV4eANWLPI9Mlk64"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 220,
    "path": "../public/assets/dollar-sign-ColLKL6U.js"
  },
  "/assets/eye-off-BKCtyGkl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1af-+o0bkDlHcgare3kqPNde5w9kHRM"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 431,
    "path": "../public/assets/eye-off-BKCtyGkl.js"
  },
  "/assets/dashboard-DuqADnLG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6c917-hbLPpohwaKxBhfLmYFHu4vAD4wE"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 444695,
    "path": "../public/assets/dashboard-DuqADnLG.js"
  },
  "/manifest.json": {
    "type": "application/json",
    "etag": '"244-QA52B9OVrJ9YeraxYGuTTAb+GIY"',
    "mtime": "2026-09-13T08:09:35.885Z",
    "size": 580,
    "path": "../public/manifest.json"
  },
  "/sw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1496-joJAzB0IAyyWsHIJ78tmSglb8OY"',
    "mtime": "2026-09-13T17:39:25.621Z",
    "size": 5270,
    "path": "../public/sw.js"
  },
  "/assets/AdminDashboard-CjZ_Xp-1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d9a09-2KDrWsZx6bgM1FtKC8lS9ERieB8"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 891401,
    "path": "../public/assets/AdminDashboard-CjZ_Xp-1.js"
  },
  "/assets/faq-_oLs-p_T.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"23d2-L1QdTyY9oz2dqsdbeityZH+06ek"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 9170,
    "path": "../public/assets/faq-_oLs-p_T.js"
  },
  "/assets/favorites-CmTv2008.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"59ec-iFnGlb/oYsK0/2FU2FRr+wrJeAM"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 23020,
    "path": "../public/assets/favorites-CmTv2008.js"
  },
  "/assets/file-spreadsheet-BWBH-meG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1ad-WLbIFmUq5iHmaFtk6gNDlT11xaM"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 429,
    "path": "../public/assets/file-spreadsheet-BWBH-meG.js"
  },
  "/assets/index-CJeXGUu-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"14b7-MQmKgMlNtataOk5a6hPu/PpUQsc"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 5303,
    "path": "../public/assets/index-CJeXGUu-.js"
  },
  "/assets/index-Dr1xC36v.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"74e5-vVuh8oSi/f05jSl1b33KkO4WD0s"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 29925,
    "path": "../public/assets/index-Dr1xC36v.js"
  },
  "/assets/languages-CCZMCShB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"270-czXdD3MqRcEBJ5J/0uWX0nGyty4"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 624,
    "path": "../public/assets/languages-CCZMCShB.js"
  },
  "/assets/lock-B0Vp0DkN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ca-CrsjPU33I4AyiID6ZZnRC1aCISY"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 202,
    "path": "../public/assets/lock-B0Vp0DkN.js"
  },
  "/assets/map-C8UorX64.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1aa-LREFPaHuzjlj0mlDVyXT7n6P/YU"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 426,
    "path": "../public/assets/map-C8UorX64.js"
  },
  "/assets/map-pinned-Cs_8n32e.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"190-ZhVQI1zMycRAH0bNHaLgAbAgNvs"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 400,
    "path": "../public/assets/map-pinned-Cs_8n32e.js"
  },
  "/assets/LeafletMap-Cq_Gu0qd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"25934-aQdbT8ISJzgpvixZmcraGHOJHaQ"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 153908,
    "path": "../public/assets/LeafletMap-Cq_Gu0qd.js"
  },
  "/assets/messages-CCGai6bN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2334-UrsYePb27YuMMi4WgiP5qir6n7o"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 9012,
    "path": "../public/assets/messages-CCGai6bN.js"
  },
  "/assets/messages-CCgDePvE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7798-yguHShFi1txsb1Kk+lEYIn2PQgs"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 30616,
    "path": "../public/assets/messages-CCgDePvE.js"
  },
  "/assets/messages_._userId-RTJkEbir.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1503-zufCxuw6QO6F8mEJLQpgPnywAGc"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 5379,
    "path": "../public/assets/messages_._userId-RTJkEbir.js"
  },
  "/assets/mock-data-hAt1jloX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1386-HcOxeJbem8j3yUyIbXSOdON7Bko"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 4998,
    "path": "../public/assets/mock-data-hAt1jloX.js"
  },
  "/assets/new-DCvj7Z2-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4451-EaPf7QONfLpJbhzdKPq8fpTKB3g"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 17489,
    "path": "../public/assets/new-DCvj7Z2-.js"
  },
  "/assets/pen-line-VTtY_PvP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"116-0VuY/O336hsjpiWsUFWiDNl0Pms"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 278,
    "path": "../public/assets/pen-line-VTtY_PvP.js"
  },
  "/assets/popover-BhWjLHct.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"146e-azZ2xVE78YF/H2bQ/57DglhrQJQ"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 5230,
    "path": "../public/assets/popover-BhWjLHct.js"
  },
  "/assets/PieChart-BEkZ51o1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"8fbc-eR2iCnwFxGfPbRklLAYCErXuh60"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 36796,
    "path": "../public/assets/PieChart-BEkZ51o1.js"
  },
  "/assets/power-BEH1zjAP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"195-Ox9Dp8OoXY+5OI3C6KMMIN5gnFA"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 405,
    "path": "../public/assets/power-BEH1zjAP.js"
  },
  "/assets/privacy-Bri86W9E.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"31e9-isNT9eLceinI1jthZG6m1CtJebY"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 12777,
    "path": "../public/assets/privacy-Bri86W9E.js"
  },
  "/assets/profile-R5I4yhSC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"15aa-h5oatMCjv2eJVHhlS/9EA8HgYs8"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 5546,
    "path": "../public/assets/profile-R5I4yhSC.js"
  },
  "/assets/reports-1hHb7vtw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1384-pvI/i65/tu490krXAsh0EtNnATc"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 4996,
    "path": "../public/assets/reports-1hHb7vtw.js"
  },
  "/assets/reports-DoF_bXl_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5055-dp8Efph+fyx2dZhzd6VC7DdOJKo"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 20565,
    "path": "../public/assets/reports-DoF_bXl_.js"
  },
  "/assets/reset-password-BtWY3COh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1251-NxkZ4bnTRPlg4g2ZzGg/V1pc7EM"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 4689,
    "path": "../public/assets/reset-password-BtWY3COh.js"
  },
  "/assets/index-C3JyO3Qd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"19ae52-24K05/4dH2Ftxh2k58GAsF0vg80"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 1683026,
    "path": "../public/assets/index-C3JyO3Qd.js"
  },
  "/assets/save-Ci0AQWoI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"148-rvKeYAAOffc/xrNO6D0tseWF9nI"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 328,
    "path": "../public/assets/save-Ci0AQWoI.js"
  },
  "/assets/search-CqtNV7qP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"e6c4-toLN2lqzLz970NYr/aNr/q8Ko1A"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 59076,
    "path": "../public/assets/search-CqtNV7qP.js"
  },
  "/assets/settings-107qQSlq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4392-4hqQ2Vt8zMUkvUDJLj8mSKku01Q"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 17298,
    "path": "../public/assets/settings-107qQSlq.js"
  },
  "/assets/square-pen-DKC7WYeL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"141-UXYJofcG40AZ2/H9FbsYutj2Ylw"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 321,
    "path": "../public/assets/square-pen-DKC7WYeL.js"
  },
  "/assets/settings-Beb55VbD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"92e2-np51T4REWSxa8VgflnXqmDG66y8"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 37602,
    "path": "../public/assets/settings-Beb55VbD.js"
  },
  "/assets/store._id-DwVoGlbK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"9ae1-HP7muSA/aeclnJdVP52nbVxc/qI"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 39649,
    "path": "../public/assets/store._id-DwVoGlbK.js"
  },
  "/assets/stores-4YcuGiEf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2fad-TxWHnk8eJTKRTMr+lfh7LvMwumg"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 12205,
    "path": "../public/assets/stores-4YcuGiEf.js"
  },
  "/assets/switch-BzmeKCA_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1049-hmw6oi0D6nP15AtQszKhzOQLpaw"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 4169,
    "path": "../public/assets/switch-BzmeKCA_.js"
  },
  "/assets/table-B5yz9S0u.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"61a-S3fhtTXBDctWWNKzWyjRjlSAy/4"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 1562,
    "path": "../public/assets/table-B5yz9S0u.js"
  },
  "/assets/target-NHJtAVUJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"de-HyInMz8F8pzkmQKgUZjLFZN7MDA"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 222,
    "path": "../public/assets/target-NHJtAVUJ.js"
  },
  "/assets/terms-B7tMkVfa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2610-RT0EDBJoXbOL7n/bj+WYbPQaL1E"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 9744,
    "path": "../public/assets/terms-B7tMkVfa.js"
  },
  "/assets/timer-YmmkgguK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1e7-BcsaDWhMylRTaeakiPJkwcYy3uc"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 487,
    "path": "../public/assets/timer-YmmkgguK.js"
  },
  "/assets/user-check-pgq1Nm85.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ef-+k52P4pge1wEpgQrgd5PYJz8vLo"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 239,
    "path": "../public/assets/user-check-pgq1Nm85.js"
  },
  "/assets/styles-aRsTn_cj.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"6f579-f0rcUioA+aMFusLe8fglzTTNcgk"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 456057,
    "path": "../public/assets/styles-aRsTn_cj.css"
  },
  "/assets/user-round-plus-DqSvHJ2z.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"22f-5VNZqQhfPq4MLGrnCDIIRMOdBFk"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 559,
    "path": "../public/assets/user-round-plus-DqSvHJ2z.js"
  },
  "/assets/user-x--phtuQdD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"133-1rJTSadivFDVEgIp4EimE7otwwQ"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 307,
    "path": "../public/assets/user-x--phtuQdD.js"
  },
  "/assets/users-round-pM1Xuj0R.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"f9-fg/pBEZM92KUKbMppPOUDSOf1Fk"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 249,
    "path": "../public/assets/users-round-pM1Xuj0R.js"
  },
  "/assets/wallet-DzT91SI9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"20c-i3BFUOYOazM9omXlCMG/xehomb4"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 524,
    "path": "../public/assets/wallet-DzT91SI9.js"
  },
  "/assets/_id-CDgwP3WT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"453f-nU7cIT9nzZu3zKPInhCvKPoJRK4"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 17727,
    "path": "../public/assets/_id-CDgwP3WT.js"
  },
  "/assets/_id-CJZZZ9vc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3b48-CDxU/tlL8ju6dNnMFhHvkLuksrQ"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 15176,
    "path": "../public/assets/_id-CJZZZ9vc.js"
  },
  "/assets/_orderId-BKZ__DTt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"30dd-cDK6fBbt6QLRYE/GvmkjwpVQuVA"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 12509,
    "path": "../public/assets/_orderId-BKZ__DTt.js"
  },
  "/assets/_slug-Cyshwey-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"36db-aALMMoQdRuowf/CeZgieleMjIdE"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 14043,
    "path": "../public/assets/_slug-Cyshwey-.js"
  },
  "/assets/_trackingNumber-C6EQcgbW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"30f5-lSv5TPmVnAHN+YIOM7YLb4USVo0"',
    "mtime": "2026-09-14T09:38:27.523Z",
    "size": 12533,
    "path": "../public/assets/_trackingNumber-C6EQcgbW.js"
  },
  "/banners/banner-electronics.jpg": {
    "type": "image/jpeg",
    "etag": '"1782b-xHAJLXtdjcvi4ownICzFvwzcqRU"',
    "mtime": "2026-07-19T07:11:02.000Z",
    "size": 96299,
    "path": "../public/banners/banner-electronics.jpg"
  },
  "/banners/banner-fashion.jpg": {
    "type": "image/jpeg",
    "etag": '"28421-R5M0K734HbOSu1fx8Aqd8Mco5J0"',
    "mtime": "2026-07-19T07:11:02.000Z",
    "size": 164897,
    "path": "../public/banners/banner-fashion.jpg"
  },
  "/images/delivery-man.png": {
    "type": "image/png",
    "etag": '"1d871-/iw6l6jYFn8clrNd00t+5DjCsFw"',
    "mtime": "2026-08-14T12:20:01.250Z",
    "size": 120945,
    "path": "../public/images/delivery-man.png"
  },
  "/images/Logo-transparent.png": {
    "type": "image/png",
    "etag": '"3b348-1ZHVNdG+6R8wG4DAV9jIJ1asbUc"',
    "mtime": "2026-09-03T07:09:05.003Z",
    "size": 242504,
    "path": "../public/images/Logo-transparent.png"
  },
  "/banners/banner-offers.jpg": {
    "type": "image/jpeg",
    "etag": '"1bf83-sM2jF7ALBpKHHZo6QMYUC2XK4V4"',
    "mtime": "2026-07-19T07:11:02.000Z",
    "size": 114563,
    "path": "../public/banners/banner-offers.jpg"
  },
  "/images/Logo.png": {
    "type": "image/png",
    "etag": '"3f8a6-46+Boc3GINzs/GcaPNaX6qXYgpY"',
    "mtime": "2026-09-02T14:28:18.558Z",
    "size": 260262,
    "path": "../public/images/Logo.png"
  },
  "/images/download.jfif": {
    "type": "image/pjpeg",
    "etag": '"196c-tDuMLHaUfJNy1yg3qfzny+NqVEM"',
    "mtime": "2026-08-31T14:52:34.191Z",
    "size": 6508,
    "path": "../public/images/download.jfif"
  }
};
function readAsset(id) {
  const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
  return promises.readFile(resolve(serverDir, assets[id].path));
}
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
function getAsset(id) {
  return assets[id];
}
const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = {
  gzip: ".gz",
  br: ".br",
  zstd: ".zst"
};
const _3E5Iak = defineHandler((event) => {
  if (event.req.method && !METHODS.has(event.req.method)) {
    return;
  }
  let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
  let asset;
  const encodingHeader = event.req.headers.get("accept-encoding") || "";
  const encodings = [...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.res.headers.delete("Cache-Control");
      throw new HTTPError({ status: 404 });
    }
    return;
  }
  if (encodings.length > 1) {
    event.res.headers.append("Vary", "Accept-Encoding");
  }
  const ifNotMatch = event.req.headers.get("if-none-match") === asset.etag;
  if (ifNotMatch) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  const ifModifiedSinceH = event.req.headers.get("if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  if (asset.type) {
    event.res.headers.set("Content-Type", asset.type);
  }
  if (asset.etag && !event.res.headers.has("ETag")) {
    event.res.headers.set("ETag", asset.etag);
  }
  if (asset.mtime && !event.res.headers.has("Last-Modified")) {
    event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.res.headers.has("Content-Encoding")) {
    event.res.headers.set("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.res.headers.has("Content-Length")) {
    event.res.headers.set("Content-Length", asset.size.toString());
  }
  return readAsset(id);
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }];
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
    let s = p.split("/"), l = s.length;
    if (l > 1) {
      if (s[1] === "assets") {
        r.unshift({ data: $0, params: { "_": s.slice(2).join("/") } });
      }
    }
    return r;
  };
})();
const _lazy_EbIvaC = defineLazyEventHandler(() => import("./_chunks/renderer-template.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_EbIvaC };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const globalMiddleware = [
  toEventHandler(_3E5Iak)
].filter(Boolean);
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
function createNitroApp() {
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({ error, context: errorCtx });
      }
    }
  };
  const h3App = createH3App({
    onError(error, event) {
      return errorHandler(error, event);
    }
  });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  return {
    fetch: appHandler,
    h3: h3App,
    hooks: void 0,
    captureError
  };
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
  h3App["~middleware"].push(...globalMiddleware);
  h3App["~getMiddleware"] = (event, route) => {
    const pathname = event.url.pathname;
    const method = event.req.method;
    const middleware = [];
    const routeRules = getRouteRules(method, pathname);
    event.context.routeRules = routeRules?.routeRules;
    if (routeRules?.routeRuleMiddleware.length) {
      middleware.push(...routeRules.routeRuleMiddleware);
    }
    middleware.push(...h3App["~middleware"]);
    if (route?.data?.middleware?.length) {
      middleware.push(...route.data.middleware);
    }
    return middleware;
  };
  return h3App;
}
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function getRouteRules(method, pathname) {
  const m = findRouteRules(method, pathname);
  if (!m?.length) {
    return { routeRuleMiddleware: [] };
  }
  const routeRules = {};
  for (const layer of m) {
    for (const rule of layer.data) {
      const currentRule = routeRules[rule.name];
      if (currentRule) {
        if (rule.options === false) {
          delete routeRules[rule.name];
          continue;
        }
        if (typeof currentRule.options === "object" && typeof rule.options === "object") {
          currentRule.options = {
            ...currentRule.options,
            ...rule.options
          };
        } else {
          currentRule.options = rule.options;
        }
        currentRule.route = rule.route;
        currentRule.params = {
          ...currentRule.params,
          ...layer.params
        };
      } else if (rule.options !== false) {
        routeRules[rule.name] = {
          ...rule,
          params: layer.params
        };
      }
    }
  }
  const middleware = [];
  const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
  for (const rule of orderedRules) {
    if (rule.options === false || !rule.handler) {
      continue;
    }
    middleware.push(rule.handler(rule));
  }
  return {
    routeRules,
    routeRuleMiddleware: middleware
  };
}
function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
  process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
  process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
const tracingSrvxPlugins = [];
const _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
const port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
const host = process.env.NITRO_HOST || process.env.HOST;
const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
serve({
  port,
  hostname: host,
  tls: cert && key ? {
    cert,
    key
  } : void 0,
  fetch: nitroApp.fetch,
  plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
const nodeServer = {};
export {
  nodeServer as default
};
